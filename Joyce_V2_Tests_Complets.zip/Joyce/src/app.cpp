#include "joyce/app.hpp"

#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>

namespace joyce {
namespace {
std::string nowText() {
    const std::time_t now = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &now);
#else
    localtime_r(&now, &tm);
#endif
    char buffer[32]{};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &tm);
    return buffer;
}
std::string trimLeft(std::string value) {
    const auto first = value.find_first_not_of(" \t");
    return first == std::string::npos ? std::string{} : value.substr(first);
}
}

App::App(Config config)
    : config_(std::move(config)), memory_(config_.memoryFile, config_.maxMessages),
      ollama_(config_), journal_(nlohmann::json::object()) {}

bool App::loadJournal() {
    std::ifstream file(journalFile_);
    if (!file) {
        journal_ = {{"sessions", nlohmann::json::array()}, {"current", nullptr}};
        return saveJournal();
    }
    try {
        file >> journal_;
        if (!journal_.is_object()) journal_ = nlohmann::json::object();
        if (!journal_.contains("sessions") || !journal_["sessions"].is_array())
            journal_["sessions"] = nlohmann::json::array();
        if (!journal_.contains("current")) journal_["current"] = nullptr;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Journal de parties illisible : " << e.what() << "\n";
        journal_ = {{"sessions", nlohmann::json::array()}, {"current", nullptr}};
        return saveJournal();
    }
}

bool App::saveJournal() const {
    namespace fs = std::filesystem;
    try {
        fs::create_directories(fs::path(journalFile_).parent_path());
        const std::string tmp = journalFile_ + ".tmp";
        { std::ofstream out(tmp, std::ios::trunc); if (!out) return false; out << journal_.dump(2) << '\n'; if (!out) return false; }
        std::error_code ec;
        fs::rename(tmp, journalFile_, ec);
        if (ec) { fs::remove(journalFile_, ec); ec.clear(); fs::rename(tmp, journalFile_, ec); }
        return !ec;
    } catch (...) { return false; }
}

void App::printHelp() const {
    std::cout << "Commandes disponibles :\n"
              << "  /help                         Afficher cette aide\n"
              << "  /profil                       Afficher le profil persistant\n"
              << "  /profil-set <champ> <valeur>  Modifier un champ du profil\n"
              << "  /status                       Afficher l'état de Joyce et d'Apex\n"
              << "  /apex                         Vérifier la source d'observation\n"
              << "  /coach <situation>            Obtenir un conseil tactique Apex\n"
              << "  /partie nouvelle <légende>    Démarrer une fiche de partie\n"
              << "  /note <observation>           Ajouter une note à la partie\n"
              << "  /fin [kills] [dégâts] [rang]  Terminer et enregistrer la partie\n"
              << "  /bilan                        Analyser la dernière partie enregistrée\n"
              << "  /stats                        Résumé des parties enregistrées\n"
              << "  /reset                        Effacer l'historique de discussion\n"
              << "  /quit                         Quitter Joyce\n\n"
              << "Les commandes de coaching utilisent les informations que tu saisis ; Joyce ne lit pas le jeu en direct.\n\n";
}

void App::printStatus() const {
    const Observation observation = apex_.observe();
    std::cout << "Modèle Ollama : " << config_.model << '\n'
              << "API : " << config_.apiUrl << '\n'
              << "Fichier mémoire : " << config_.memoryFile << '\n'
              << "Messages conservés : " << memory_.messages().size() << '\n'
              << "Parties enregistrées : " << journal_["sessions"].size() << '\n'
              << "Observation Apex : " << (observation.available ? "disponible" : "non connectée")
              << " (source : " << observation.source << ")\n\n";
}

void App::printStats() const {
    const auto& sessions = journal_["sessions"];
    std::size_t totalKills = 0;
    double totalDamage = 0.0;
    std::size_t damageCount = 0;
    for (const auto& s : sessions) {
        if (s.contains("kills") && s["kills"].is_number_integer()) totalKills += s["kills"].get<std::size_t>();
        if (s.contains("damage") && s["damage"].is_number()) { totalDamage += s["damage"].get<double>(); ++damageCount; }
    }
    std::cout << "Parties enregistrées : " << sessions.size() << "\nTotal éliminations : " << totalKills << '\n';
    if (damageCount) std::cout << "Dégâts moyens saisis : " << static_cast<long>(totalDamage / damageCount) << '\n';
    if (journal_["current"].is_object()) std::cout << "Partie en cours : oui (" << journal_["current"].value("legend", "légende inconnue") << ")\n";
    else std::cout << "Partie en cours : non\n";
    std::cout << '\n';
}

void App::coach(const std::string& situation) {
    if (situation.empty()) { std::cout << "Usage : /coach <situation, position, équipement, équipe adverse...>\n\n"; return; }
    const std::string prompt = "Agis comme coach tactique Apex Legends. Analyse uniquement les informations fournies, distingue les faits des hypothèses, puis donne : 1) priorité immédiate, 2) plan de 10 à 20 secondes, 3) risque principal, 4) alternative si le plan échoue. Sois concis et ne prétends pas voir la partie. Situation fournie : " + situation;
    std::string answer, error;
    std::cout << "Joyce analyse la situation...\n";
    if (!ollama_.ask(prompt, memory_, answer, error)) { std::cerr << "Erreur Ollama : " << error << "\n\n"; return; }
    std::cout << "\nCoach Joyce > " << answer << "\n\n";
    memory_.addExchange(prompt, answer);
}

void App::reviewLastSession() {
    nlohmann::json session;
    if (journal_["current"].is_object()) session = journal_["current"];
    else if (!journal_["sessions"].empty()) session = journal_["sessions"].back();
    else { std::cout << "Aucune partie enregistrée. Utilise /partie nouvelle <légende>.\n\n"; return; }
    const std::string prompt = "Agis comme coach de progression Apex Legends. Fais un bilan bienveillant et concret à partir de cette fiche saisie manuellement : " + session.dump(2) + ". Donne les points forts possibles, les axes à travailler, et trois exercices précis. Signale ce qui manque au lieu d'inventer des statistiques. Joyce ne dispose pas de données de jeu automatiques.";
    std::string answer, error;
    std::cout << "Joyce prépare le bilan...\n";
    if (!ollama_.ask(prompt, memory_, answer, error)) { std::cerr << "Erreur Ollama : " << error << "\n\n"; return; }
    std::cout << "\nBilan Joyce > " << answer << "\n\n";
    memory_.addExchange(prompt, answer);
}

void App::handleInput(const std::string& input, bool& keepRunning) {
    if (input == "/quit" || input == "/exit") { keepRunning = false; return; }
    if (input == "/help") { printHelp(); return; }
    if (input == "/profil") { std::cout << memory_.profile().dump(2) << "\n\n"; return; }
    if (input.rfind("/profil-set ", 0) == 0) {
        std::istringstream stream(input.substr(12));
        std::string key; stream >> key;
        std::string value; std::getline(stream, value); value = trimLeft(value);
        if (key.empty() || value.empty()) { std::cout << "Usage : /profil-set <champ> <valeur>\nExemple : /profil-set main_legend Wraith\n\n"; return; }
        if (key == "name" || key == "language" || key == "style" || key == "project" || key == "main_legend" || key == "goals" || key == "playstyle") {
            memory_.profile()[key] = value;
            if (memory_.save()) std::cout << "Profil mis à jour : " << key << " = " << value << "\n\n";
            else std::cout << "Profil modifié en mémoire, mais sauvegarde échouée.\n\n";
        } else std::cout << "Champ non autorisé. Champs : name, language, style, project, main_legend, goals, playstyle.\n\n";
        return;
    }
    if (input == "/status") { printStatus(); return; }
    if (input == "/apex") { const Observation o = apex_.observe(); std::cout << "Apex : " << o.summary << "\nJoyce n'analyse pas le jeu en direct ; utilise /coach avec une description de la situation.\n\n"; return; }
    if (input == "/reset") { memory_.resetHistory(); std::cout << "Historique effacé. Profil conservé.\n\n"; return; }
    if (input == "/stats") { printStats(); return; }
    if (input == "/bilan") { reviewLastSession(); return; }
    if (input.rfind("/coach", 0) == 0 && (input.size() == 6 || input[6] == ' ')) { coach(trimLeft(input.substr(6))); return; }
    if (input.rfind("/partie nouvelle", 0) == 0) {
        const std::string legend = trimLeft(input.substr(std::string("/partie nouvelle").size()));
        if (legend.empty()) { std::cout << "Usage : /partie nouvelle <légende>\n\n"; return; }
        if (journal_["current"].is_object()) { std::cout << "Une partie est déjà en cours. Termine-la avec /fin ou note-la avant d'en démarrer une autre.\n\n"; return; }
        journal_["current"] = {{"started_at", nowText()}, {"legend", legend}, {"notes", nlohmann::json::array()}, {"status", "enregistrée manuellement"}};
        std::cout << (saveJournal() ? "Fiche de partie démarrée pour " + legend + ". Utilise /note pour ajouter du contexte.\n\n" : "Erreur de sauvegarde du journal.\n\n");
        return;
    }
    if (input.rfind("/note", 0) == 0 && (input.size() == 5 || input[5] == ' ')) {
        const std::string note = trimLeft(input.substr(5));
        if (note.empty()) { std::cout << "Usage : /note <observation>\n\n"; return; }
        if (!journal_["current"].is_object()) { std::cout << "Pas de partie en cours. Démarre-en une avec /partie nouvelle <légende>.\n\n"; return; }
        journal_["current"]["notes"].push_back({{"at", nowText()}, {"text", note}});
        std::cout << (saveJournal() ? "Note enregistrée.\n\n" : "Erreur de sauvegarde de la note.\n\n");
        return;
    }
    if (input.rfind("/fin", 0) == 0 && (input.size() == 4 || input[4] == ' ')) {
        if (!journal_["current"].is_object()) { std::cout << "Aucune partie en cours.\n\n"; return; }
        std::istringstream args(input.substr(4));
        int kills = -1, damage = -1, rank = -1; args >> kills >> damage >> rank;
        if (kills >= 0) journal_["current"]["kills"] = kills;
        if (damage >= 0) journal_["current"]["damage"] = damage;
        if (rank >= 1 && rank <= 20) journal_["current"]["placement"] = rank;
        journal_["current"]["ended_at"] = nowText();
        journal_["current"]["status"] = "terminée";
        journal_["sessions"].push_back(journal_["current"]);
        journal_["current"] = nullptr;
        std::cout << (saveJournal() ? "Partie enregistrée. Utilise /bilan pour obtenir une analyse.\n\n" : "Erreur de sauvegarde du journal.\n\n");
        return;
    }
    if (!input.empty() && input.front() == '/') { std::cout << "Commande inconnue. Tape /help pour la liste.\n\n"; return; }

    std::string answer, error;
    std::cout << "Joyce réfléchit...\n";
    if (!ollama_.ask(input, memory_, answer, error)) {
        std::cerr << "Joyce n'a pas pu répondre : " << error << '\n'
                  << "Vérifie qu'Ollama est démarré et que le modèle '" << config_.model
                  << "' est installé. L'historique n'a pas été modifié.\n\n";
        return;
    }
    std::cout << "\nJoyce > " << answer << "\n\n";
    memory_.addExchange(input, answer);
}

int App::run() {
    if (!memory_.load()) std::cerr << "Attention : la mémoire n'a pas pu être sauvegardée.\n";
    if (!loadJournal()) std::cerr << "Attention : le journal des parties n'a pas pu être sauvegardé.\n";
    std::cout << "========================================\n"
              << " Joyce - Assistant IA local\n"
              << " Modèle : " << config_.model << "\n"
              << " Mémoire : " << config_.memoryFile << "\n"
              << " Tape /help pour les commandes.\n"
              << "========================================\n\n";
    bool keepRunning = true;
    std::string input;
    while (keepRunning) { std::cout << "Toi > " << std::flush; if (!std::getline(std::cin, input)) break; if (input.empty()) continue; handleInput(input, keepRunning); }
    std::cout << "Joyce est arrêtée. La mémoire est conservée.\n";
    return 0;
}

} // namespace joyce
