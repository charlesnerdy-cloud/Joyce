# Joyce V5.4 — perception locale et prototype de coéquipier neuronal

Joyce est une application en ligne de commande C++17 qui utilise Ollama local. Cette V5.2 prolonge V5.1, conserve les commandes V2 et ajoute un coaching plus contextualisé, des tendances calculées sur les fiches enregistrées, et l'import/export JSON des données fournies par le joueur.

## Ce que fait V5.1

- **Profil personnalisé** : légende principale, objectifs et style de jeu intégrés au contexte de coaching.
- **Fiches de parties persistantes** : notes horodatées, éliminations, dégâts, placement, sauvegarde après redémarrage.
- **Coaching tactique** : priorité immédiate, plan de 10–20 secondes, risque et solution de repli.
- **Bilan d'une partie** : points forts possibles, axes de travail et exercices, sans inventer les statistiques absentes.
- **Insights de progression** : moyennes disponibles et plan de travail basé sur les dernières fiches.
- **Import/export JSON** : importer un objet, un tableau de parties ou un document contenant `sessions` ou `matches`; exporter le journal local.
- **Analyse visuelle locale** : moteur C++17/OpenCV pour les images et vidéos fournies par le joueur.
- **Wrapper Python** : `scripts/vision.py` valide les paramètres, lance le moteur natif, puis lit et résume le rapport JSON.
- **Interprétation Ollama** : `scripts/vision_coach.py` transmet uniquement les métriques structurées à Ollama, valide la réponse JSON et enregistre résumé, observations, hypothèses et recommandations. Le dashboard affiche la dernière interprétation.
- **Tests automatisés** : serveur Ollama simulé et tests du wrapper Python; aucun accès Internet ni vrai modèle nécessaire pour les tests.

## Limite volontaire concernant Apex

Joyce **n'observe pas automatiquement la partie** dans cette version. L'import concerne un fichier JSON que tu possèdes et choisis de fournir; il ne s'agit pas d'une connexion officielle automatique aux serveurs Apex. Aucun accès à la mémoire du jeu, aucune injection de commandes et aucun contournement de l'anti-triche ne sont implémentés. Les champs absents d'un fichier restent inconnus.

## Installation (Debian/Ubuntu)

```bash
sudo apt update
sudo apt install -y build-essential cmake pkg-config libcurl4-openssl-dev nlohmann-json3-dev libopencv-dev python3 python3-opencv
```

Installer Ollama depuis sa source officielle, puis :

```bash
ollama pull qwen2.5:3b
curl http://localhost:11434/api/tags
./scripts/build.sh
./scripts/run.sh
```

Si tu as déjà une version de Joyce, extrais ce paquet dans un dossier temporaire puis lance le script d’installation en passant le chemin de ton projet existant :

```bash
./scripts/install_v5_1.sh "$HOME/workspace/Joyce/Joyce"
```

Le script sauvegarde les fichiers source remplacés dans un dossier de sauvegarde et **ne touche pas** au dossier `data/` ni aux données de parties ou de profil. Vérifie le chemin si ton projet se trouve ailleurs.

## Commandes

- `/help` : liste des commandes.
- `/profil` : afficher le profil.
- `/profil-set main_legend Wraith` : définir la légende principale.
- `/profil-set goals Améliorer le placement en fin de partie` : définir un objectif (les espaces sont acceptés).
- `/status` et `/apex` : état de Joyce; rappelle que l'observation en direct n'est pas connectée.
- `/coach deux équipes nous poussent, nous sommes derrière un rocher et la zone ferme` : conseil tactique à partir de ta description.
- `/partie nouvelle Wraith`, puis `/note ...`, puis `/fin 2 850 4` : enregistrer une partie (éliminations, dégâts, rang).
- `/bilan` : analyser la dernière partie.
- `/stats` : statistiques descriptives sur les données enregistrées.
- `/insights` : demander un plan de progression basé sur l'historique disponible.
- `/import-json "/chemin/vers/mes_stats.json"` : importer les parties d'un fichier JSON local.
- `/export-json "/chemin/vers/backup.json"` : exporter le journal de parties.
- `/reset` : effacer seulement l'historique de conversation; le profil et les fiches de partie restent.
- `/quit` : quitter.

### Format JSON d'import

Un fichier peut être un tableau de parties, un objet partie, ou un objet contenant `sessions` ou `matches`. Les noms de champs reconnus sont `legend`, `kills`, `damage`, `placement`, `date`, `started_at`, `ended_at` et `notes`. Exemple :

```json
{
  "sessions": [
    {"legend": "Wraith", "kills": 3, "damage": 1200, "placement": 2, "date": "2026-10-24"},
    {"legend": "Lifeline", "kills": 1, "damage": 430, "placement": 8}
  ]
}
```

C'est un format générique d'import, pas une promesse de compatibilité avec un export officiel d'Apex. Les valeurs manquantes ne sont pas calculées ni devinées.

## Analyse d’image ou de vidéo avec le wrapper Python

```bash
python3 scripts/vision.py "/chemin/vers/capture.png"
python3 scripts/vision.py "/chemin/vers/partie.mp4" --sample-seconds 1.5 --out data/rapport.json
# Analyse visuelle puis interprétation avec Ollama local :
python3 scripts/vision.py "/chemin/vers/partie.mp4" --sample-seconds 1.5 --coach
# Ou interpréter un rapport existant :
python3 scripts/vision_coach.py data/joyce_vision_report.json --out data/joyce_vision_analysis.json
# Équivalent raccourci (métriques seulement) :
./scripts/vision.sh "/chemin/vers/partie.mp4"
```

Le wrapper construit le moteur C++ si nécessaire, puis affiche un résumé du rapport JSON. Il ne capture pas l’écran, ne contrôle pas le jeu et ne reconnaît pas encore sémantiquement les adversaires, les dégâts ou les éliminations. Les mesures actuelles sont des indicateurs bas niveau (luminosité, contours et différences entre images). Le modèle textuel reçoit ces métriques, pas les pixels : il ne peut donc pas identifier les ennemis ou événements à partir de ce rapport. Les réponses du modèle sont validées comme JSON et leurs limites sont affichées dans le dashboard.

## Tests automatisés

```bash
./scripts/test_all.sh
```

Le script compile Joyce et exécute des tests avec une API Ollama simulée. Il teste les commandes, le profil, les fiches de parties, la persistance, le coaching, les insights et l'import/export. Cela valide le programme et son protocole HTTP, mais pas la qualité des réponses du vrai modèle.

## Configuration

```bash
export JOYCE_MODEL='qwen2.5:3b'
export JOYCE_API_URL='http://localhost:11434/api/chat'
export JOYCE_MEMORY_FILE='data/joyce_memory.json'
export JOYCE_MATCHES_FILE='data/joyce_matches.json'
./scripts/run.sh
```

Par défaut, les appels sont adressés à `localhost`. Si tu changes `JOYCE_API_URL` pour un serveur distant, tes messages seront transmis à ce serveur.

## V5.3 — vision multimodale locale et mémoire

V5.3 ajoute `scripts/vision_model.py`, qui envoie les pixels d'une capture à un modèle de vision Ollama, enregistre les observations horodatées en JSONL et peut croiser la description avec `qwen2.5:3b`. L'analyse reste locale. La vidéo est échantillonnée par OpenCV; les images individuelles sont envoyées une par une au modèle.

### Préparation

```bash
ollama pull qwen2.5vl:3b
ollama pull qwen2.5:3b
```

Lance Ollama dans un autre terminal si le service n'est pas déjà actif. Vérifie le modèle de vision disponible avec `ollama list`.

### Captures et vidéos

```bash
# Analyse d'une capture, avec vrai contenu image
python3 scripts/vision_model.py "/chemin/capture.png"

# Analyse de 8 images au maximum, une toutes les 1,5 s, puis second avis texte
python3 scripts/vision_model.py "/chemin/partie.mp4" --sample-seconds 1.5 --max-frames 8 --reason

# Surveillance d'un dossier de captures (Ctrl+C pour arrêter)
mkdir -p "$HOME/Joyce-captures"
python3 scripts/vision_model.py "$HOME/Joyce-captures" --watch --reason
```

Dépose ou enregistre des captures dans le dossier surveillé. Joyce ne capture pas elle-même l'écran et n'interagit pas avec Apex. Le mode veille analyse uniquement les nouveaux fichiers image du dossier; les fichiers vidéo sont analysés via la commande normale.

### Historique et configuration

- Historique local append-only : `data/joyce_vision_history.jsonl`.
- `--history /chemin/historique.jsonl` change le fichier de sortie.
- `--vision-model qwen2.5vl:3b` change le modèle multimodal.
- `--text-model qwen2.5:3b --reason` active le second passage de raisonnement.
- Variables : `JOYCE_API_URL`, `JOYCE_VISION_MODEL`, `JOYCE_MODEL`, `JOYCE_VISION_HISTORY`.
- `--no-reason` est accepté pour compatibilité; le raisonnement croisé est désactivé par défaut et activé uniquement avec `--reason`.

### Limites

La vision IA peut manquer ou mal interpréter des éléments, surtout en mouvement, à faible résolution ou sur une image partielle. Les noms de modèles disponibles varient selon l'installation Ollama; télécharge les modèles avant usage. Aucun pilotage du jeu, injection, contournement anti-triche ou connexion à un processus Apex n'est implémenté.


## V5.4 — prototype de politique neuronale (nouveau)

`scripts/teammate_nn.py` ajoute un petit perceptron multicouche (MLP) en Python pur : aucune dépendance PyTorch, aucun GPU obligatoire. Il prend un état de jeu **fourni explicitement en JSON**, produit une recommandation tactique et ajoute une ligne horodatée à `data/joyce_teammate_history.jsonl`. Il n’envoie aucune entrée au jeu et ne lit pas la mémoire du processus Apex.

### Démo en une commande

```bash
python3 scripts/teammate_nn.py --demo
```

### Faire une recommandation depuis un état fourni

```bash
cat > /tmp/joyce_state.json <<'JSON'
{
  "health": 35, "shield": 20, "ammo": 90, "enemies": 2,
  "teammates_alive": 3, "zone_pressure": 0.4, "cover": 0.8, "squad_distance": 15
}
JSON
python3 scripts/teammate_nn.py --state /tmp/joyce_state.json
```

Les champs `health` et `shield` acceptent une valeur 0–100 ou normalisée 0–1. `ammo` peut être une quantité ou une valeur 0–1. `enemies`, `teammates_alive`, `zone_pressure`, `cover` et `squad_distance` sont normalisés automatiquement quand c’est pertinent. Les entrées inconnues prennent des valeurs par défaut : pour une recommandation utile, fournir un état complet.

### Entraîner sur des exemples annotés

Crée un fichier JSONL où chaque ligne associe un état à une action choisie par un humain :

```json
{"state":{"health":25,"shield":10,"ammo":40,"enemies":2,"teammates_alive":3,"zone_pressure":0.4,"cover":0.9,"squad_distance":10},"action":"heal_or_recharge"}
{"state":{"health":90,"shield":80,"ammo":220,"enemies":1,"teammates_alive":3,"zone_pressure":0.2,"cover":0.8,"squad_distance":5},"action":"engage"}
```

Enregistre ces lignes dans `data/joyce_training.jsonl`, puis :

```bash
python3 scripts/teammate_nn.py --train data/joyce_training.jsonl --epochs 250
```

Actions acceptées : `take_cover`, `heal_or_recharge`, `regroup`, `reposition`, `engage`. Le fichier de modèle est `data/joyce_policy_nn.json`; l’historique est `data/joyce_teammate_history.jsonl`.

**Important :** le jeu de démarrage est synthétique et ses étiquettes proviennent de règles heuristiques. Il sert à vérifier le pipeline, pas à prétendre que le NN sait déjà jouer à Apex. Pour de vraies performances, il faut des exemples représentatifs annotés et une évaluation séparée. Les probabilités sont des scores du modèle, pas une garantie de confiance. Le système reste un prototype d’analyse/recommandation, sans pilotage de personnage ni contournement de l’anti-triche.
