# Joyce V6 — All-in-One Companion (prototype local)

Joyce V6 regroupe les briques présentes dans V5.4 et ajoute une interface compagnon locale : session avec PIN, état « prêt » interne, profil persistant, objectifs, retours annotés, recommandations du petit MLP et accès à l’analyse d’images Ollama.

> **Limite d’intégration Apex :** cette version ne se connecte pas aux serveurs ou au processus Apex, ne rejoint pas une escouade, n’envoie pas de messages dans le chat du jeu et ne clique pas sur « Prêt ». L’état `PRÊT` est uniquement l’état interne du compagnon. Aucun accès mémoire, injection ou contournement anti-triche n’est présent. Les interactions en jeu nécessitent une interface autorisée par le jeu et ses règles.

## Installation — Debian trixie / Ubuntu

Depuis le dossier extrait `JoyceV6_AllInOne` :

```bash
sudo apt update
sudo apt install -y python3 python3-opencv build-essential cmake pkg-config \
  libcurl4-openssl-dev nlohmann-json3-dev libopencv-dev
chmod +x scripts/*.sh scripts/*.py
python3 tests/test_teammate_nn.py
python3 tests/test_companion.py
python3 tests/test_vision_model.py
python3 tests/test_vision_coach.py
python3 tests/test_dashboard.py
```

Lancer le client local :

```bash
./scripts/run_companion.sh
```

Le PIN de session est affiché dans stdout comme demandé. Saisis-le avec `/pin <code>` dans la même interface. Par défaut, le code expire après 180 secondes. Tu peux modifier le délai avec `--pin-ttl 300` (autorisé : 30 à 900 secondes).

**Sécurité du PIN :** puisqu’il est volontairement affiché dans stdout, ne redirige pas la sortie vers un journal partagé et ne publie pas de capture du terminal. Ce PIN valide seulement la session locale Joyce ; il n’authentifie pas Apex.

## Commandes du compagnon

- `/help` : aide.
- `/pin 123456` : exemple de syntaxe pour valider le PIN affiché au démarrage (remplace-le par le vrai code).
- `/status` : état local, profil, objectifs et nombre de leçons annotées.
- `/remember legend Wraith` : mémoriser une préférence localement.
- `/goal Améliorer mon placement en fin de partie` : ajouter un objectif.
- `/coach {"health":35,"shield":20,"ammo":0.55,"enemies":2,"teammates_alive":1,"zone_pressure":0.45,"cover":0.8,"squad_distance":0.2}` : obtenir une recommandation du NN à partir d’un état que tu fournis.
- `/feedback {"health":35,"cover":0.8,"enemies":2} take_cover helpful Cette recommandation m’a aidé` : enregistrer un retour humain annoté. Valeurs : `helpful` ou `unhelpful`.
- `/observe "/chemin/vers/capture.png"` : appeler le module de vision Ollama déjà fourni.
- `/disconnect` : terminer la session locale.
- `/quit` : quitter.

## Vision multimodale locale (Ollama)

```bash
ollama pull qwen2.5vl:3b
ollama pull qwen2.5:3b
python3 scripts/vision_model.py "/chemin/vers/capture.png" --reason
python3 scripts/vision_model.py "/chemin/vers/partie.mp4" --sample-seconds 1.5 --max-frames 8 --reason
mkdir -p "$HOME/Joyce-captures"
python3 scripts/vision_model.py "$HOME/Joyce-captures" --watch --reason
```

L’analyse de vidéo échantillonne les images via OpenCV. Le mode surveillance traite les nouvelles images déposées dans un dossier ; Joyce ne capture pas elle-même l’écran.

## Réseau neuronal et évolution contrôlée

- `scripts/teammate_nn.py --demo` entraîne le MLP de démarrage à partir d’exemples **synthétiques** et produit une recommandation de démonstration.
- Pour entraîner avec des exemples annotés, crée un fichier JSONL, une entrée par ligne :

```json
{"state":{"health":25,"shield":10,"ammo":0.4,"enemies":2,"teammates_alive":2,"zone_pressure":0.7,"cover":0.8,"squad_distance":0.1},"action":"heal_or_recharge"}
```

Puis :

```bash
python3 scripts/teammate_nn.py --train data/mes_exemples.jsonl --epochs 300
```

Les retours `/feedback` sont sauvegardés dans `data/joyce_feedback.jsonl` et dans le profil. Ils ne changent **pas** silencieusement les poids du modèle : inspecte et transforme les retours en exemples d’entraînement validés avant de réentraîner. C’est plus sûr qu’un auto-apprentissage non supervisé qui pourrait dégrader le comportement.

## Fichiers de données

- `data/joyce_profile.json` : préférences, objectifs, sessions et leçons.
- `data/joyce_companion_events.jsonl` : journal d’événements du client.
- `data/joyce_feedback.jsonl` : retours humains annotés.
- `data/joyce_policy_nn.json` : poids du MLP (créé par `--demo` ou `--train`).
- `data/joyce_teammate_history.jsonl` : historique des recommandations NN.
- `data/joyce_vision_history.jsonl` : observations visuelles locales.

Ces fichiers sont locaux. Sauvegarde le dossier `data/` avant toute mise à jour et ne le publie pas sans vérifier qu’il ne contient pas d’informations privées.

## Vérification générale

```bash
./scripts/test_all.sh
python3 tests/test_companion.py
```

La compilation C++ dépend des bibliothèques système indiquées plus haut. Les tests Python ne prouvent pas la qualité tactique du modèle ni la compatibilité avec un véritable service Apex. Le MLP est un prototype ; ses performances doivent être évaluées sur des données représentatives tenues à l’écart de l’entraînement.
