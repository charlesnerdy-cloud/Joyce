# Vérification manuelle rapide

Après compilation et démarrage (`./scripts/build.sh && ./scripts/run.sh`), saisir :

```text
/help
/profil-set main_legend Wraith
/profil
/partie nouvelle Wraith
/note Nous étions séparés de l'équipe et avons pris un combat en zone ouverte.
/fin 2 850 4
/stats
/bilan
/quit
```

Les commandes de fiche/statistiques doivent fonctionner sans Ollama. `/bilan` et `/coach` nécessitent qu'Ollama réponde sur l'API configurée. Les nombres de l'exemple sont fictifs : remplace-les par tes données.
