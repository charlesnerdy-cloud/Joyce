#!/usr/bin/env python3
import json, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import vision_model as vm

class VisionModelTests(unittest.TestCase):
    def test_image_saved_to_jsonl(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / 'capture.png'; source.write_bytes(b'fake image bytes')
            history = Path(td) / 'history.jsonl'
            with patch.object(vm, '_describe', return_value='Je vois une scène de jeu.'), patch.object(vm, '_reason', return_value={'summary':'Résumé'}):
                result = vm.analyze(source, 2.0, 5, 'vision-model', 'text-model', 2, True, history)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0]['observation'], 'Je vois une scène de jeu.')
            self.assertEqual(result[0]['reasoning']['summary'], 'Résumé')
            saved = json.loads(history.read_text().strip())
            self.assertEqual(saved['source'], str(source))
            self.assertEqual(len(saved['sha256']), 64)

    def test_no_reason_by_default(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / 'capture.jpg'; source.write_bytes(b'bytes')
            with patch.object(vm, '_describe', return_value='description'), patch.object(vm, '_reason') as reason:
                out = vm.analyze(source, 1, 1, 'vision', None, 1, False, Path(td)/'history.jsonl')
            reason.assert_not_called()
            self.assertIsNone(out[0]['reasoning'])

    def test_missing_source(self):
        with self.assertRaisesRegex(RuntimeError, 'introuvable'):
            vm.analyze(Path('/no/such/joyce-capture.png'), 1, 1, 'vision', None, 1, False, Path('/tmp/nope.jsonl'))

    def test_unsupported_extension(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/'notes.txt'; path.write_text('x')
            with self.assertRaisesRegex(RuntimeError, 'Format non pris en charge'):
                vm.analyze(path, 1, 1, 'vision', None, 1, False, Path(td)/'history.jsonl')

    def test_empty_image(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/'empty.png'; path.write_bytes(b'')
            with self.assertRaisesRegex(RuntimeError, 'Image vide'):
                vm._image_bytes(path)

if __name__ == '__main__': unittest.main(verbosity=2)
