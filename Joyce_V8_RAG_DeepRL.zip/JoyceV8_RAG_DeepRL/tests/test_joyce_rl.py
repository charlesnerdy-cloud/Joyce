import json, tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
import joyce_rl as rl

class RewardLearningTests(unittest.TestCase):
    def test_reward_mapping(self):
        self.assertEqual(rl.EVENT_REWARDS["damage"][0], -1.0)
        self.assertEqual(rl.EVENT_REWARDS["move_safe"][0], 1.0)
        self.assertEqual(rl.EVENT_REWARDS["move_damage"][0], 0.0)
    def test_mlp_updates_prediction_toward_target(self):
        m=rl.RewardMLP()
        x=rl.input_vector({"health":20,"cover":0.2},"reposition")
        before=m.predict(x)
        for _ in range(80): m.update(x,1.0)
        self.assertGreater(m.predict(x),before)
    def test_model_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"m.json";m=rl.RewardMLP();m.update([0.1]*13,0.5);m.save(path)
            n=rl.RewardMLP.load(path)
            self.assertEqual(n.steps,1)
    def test_records_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"x.jsonl"
            row={"action":"reposition","event":"move_damage","reward":0.0}
            rl.append_record(path,row)
            self.assertEqual(rl.load_records(path)[0]["event"],"move_damage")
if __name__=="__main__": unittest.main()
