import importlib.util, json, tempfile, unittest
from pathlib import Path
SCRIPT=Path(__file__).resolve().parents[1]/"scripts"/"teammate_nn.py"
spec=importlib.util.spec_from_file_location("teammate_nn",SCRIPT); nn=importlib.util.module_from_spec(spec); spec.loader.exec_module(nn)
class TeammateNNTests(unittest.TestCase):
 def test_vector_normalizes(self):
  x=nn.vector({"health":50,"shield":25,"ammo":90,"enemies":2,"teammates_alive":2,"zone_pressure":.4,"cover":1,"squad_distance":40})
  self.assertEqual(len(x),8); self.assertAlmostEqual(x[0],.5); self.assertAlmostEqual(x[2],.3); self.assertAlmostEqual(x[7],.4)
 def test_train_predict_save_load(self):
  m=nn.MLP(); m.train(nn.starter_data(80),epochs=3)
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/"model.json"; m.save(f); m2=nn.MLP.load(f); i,p=m2.predict(nn.vector({"health":.2,"cover":.1,"enemies":.8}))
   self.assertIn(i,range(5)); self.assertAlmostEqual(sum(p),1.0,places=6)
 def test_history_jsonl(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/"history.jsonl"; nn.append_history(f,{"action":"regroup"}); self.assertEqual(json.loads(f.read_text())["action"],"regroup")
 def test_heuristic_cover(self): self.assertEqual(nn.heuristic(nn.vector({"cover":0,"enemies":2})),0)
if __name__=="__main__": unittest.main()
