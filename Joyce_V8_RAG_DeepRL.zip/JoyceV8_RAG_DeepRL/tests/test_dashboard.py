#!/usr/bin/env python3
"""Tests sans dépendance externe du tableau de bord local Joyce."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("joyce_dashboard", ROOT / "scripts" / "dashboard.py")
DASH = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(DASH)


class DashboardTests(unittest.TestCase):
    def test_metrics_and_escaped_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "matches.json"
            path.write_text(json.dumps({"sessions": [
                {"legend": "Wraith", "kills": 2, "damage": 800, "placement": 4, "notes": [{"text": "ok"}]},
                {"legend": "<script>alert(1)</script>", "kills": 4, "damage": 1200, "placement": 1, "notes": []}
            ], "current": {"legend": "Lifeline", "started_at": "today"}}), encoding="utf-8")
            page = DASH.render_dashboard(path)
            self.assertIn("Parties enregistrées</div><div class=\"metric\">2", page)
            self.assertIn("2 / 1", page)
            self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", page)
            self.assertNotIn("<script>alert(1)</script>", page)
            self.assertIn("Lifeline", page)

    def test_renders_latest_vision_analysis_safely(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            matches = root / "matches.json"
            matches.write_text(json.dumps({"sessions": []}), encoding="utf-8")
            (root / "joyce_vision_analysis.json").write_text(json.dumps({
                "summary": "Scène variable", "confidence": 0.55,
                "observations": ["Luminosité mesurée"], "hypotheses": ["<script>non</script>"],
                "recommendations": ["Regarder le passage"]}), encoding="utf-8")
            page = DASH.render_dashboard(matches)
            self.assertIn("Dernière analyse visuelle + Ollama", page)
            self.assertIn("Scène variable", page)
            self.assertIn("&lt;script&gt;non&lt;/script&gt;", page)
            self.assertNotIn("<script>non</script>", page)

    def test_missing_file_is_explained(self):
        with tempfile.TemporaryDirectory() as tmp:
            page = DASH.render_dashboard(Path(tmp) / "absent.json")
            self.assertIn("Journal introuvable", page)
            self.assertIn("Aucune partie enregistrée", page)

    def test_invalid_json_is_safe(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "broken.json"
            path.write_text("not json", encoding="utf-8")
            page = DASH.render_dashboard(path)
            self.assertIn("Lecture impossible", page)
            self.assertIn("Aucune partie enregistrée", page)


if __name__ == "__main__":
    unittest.main(verbosity=2)
