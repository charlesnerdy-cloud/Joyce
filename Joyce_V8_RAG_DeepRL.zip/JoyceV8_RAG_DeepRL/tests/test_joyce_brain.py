import json, tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
import joyce_brain as jb

class BrainTests(unittest.TestCase):
    def test_move_without_state_change_no_reward(self):
        s={"health":100,"shield":100,"cover":0.5,"zone_pressure":0.2,"squad_distance":10}
        self.assertEqual(jb.derived_reward(s,s,{}),0)
    def test_damage_while_position_improves_is_discounted(self):
        s={"health":100,"cover":0.2,"zone_pressure":0.7}
        ns={"health":80,"cover":0.8,"zone_pressure":0.2}
        self.assertLess(jb.derived_reward(s,ns,{}),1.0)
    def test_damage_during_reposition_is_capped_at_zero(self):
        old=jb.TRANSITIONS
        try:
            with tempfile.TemporaryDirectory() as d:
                jb.TRANSITIONS=Path(d)/"t.jsonl"
                payload={"state":{"health":100,"cover":0.2,"zone_pressure":0.7},
                         "action":"reposition",
                         "next_state":{"health":80,"cover":0.9,"zone_pressure":0.1},
                         "events":{"damage_dealt":30}}
                # Exercise the same reward policy as ingestion.
                reward=jb.derived_reward(payload["state"],payload["next_state"],payload["events"])
                before,after=jb.vector(payload["state"]),jb.vector(payload["next_state"])
                if after[0] < before[0] or after[1] < before[1]: reward=min(0.0,reward)
                self.assertLessEqual(reward,0.0)
        finally: jb.TRANSITIONS=old

    def test_transition_reward_and_rag(self):
        old=jb.TRANSITIONS
        try:
            with tempfile.TemporaryDirectory() as d:
                jb.TRANSITIONS=Path(d)/"t.jsonl"
                row={"state":{"health":100},"action":"reposition","next_state":{"health":100,"cover":0.8},"events":{}}
                r=jb.derived_reward(row["state"],row["next_state"])
                jb.append_jsonl(jb.TRANSITIONS,{"state":row["state"],"action":row["action"],"next_state":row["next_state"],"reward":r})
                self.assertEqual(len(jb.load_transitions()),1)
                self.assertTrue(jb.rag("attribution causale",limit=5))
        finally: jb.TRANSITIONS=old
    def test_dqn_train_and_act(self):
        try: import numpy
        except ImportError: self.skipTest("numpy absent")
        rows=[]
        for i in range(12):
            s={"health":80-i,"cover":0.2+i/20,"zone_pressure":.6,"squad_distance":20}
            ns={"health":80-i,"cover":min(1,.25+i/20),"zone_pressure":.5,"squad_distance":15}
            rows.append({"s":jb.vector(s),"a":3,"r":jb.derived_reward(s,ns),"ns":jb.vector(ns),"done":i%4==0,"source":"test"})
        m=jb.DQN(); report=m.train(rows,epochs=2)
        self.assertEqual(report["transitions"],12)
        action,qs=m.act({"health":50})
        self.assertIn(action,jb.ACTIONS);self.assertEqual(len(qs),5)
if __name__=="__main__":unittest.main()
