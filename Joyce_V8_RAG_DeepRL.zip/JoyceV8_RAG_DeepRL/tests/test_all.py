#!/usr/bin/env python3
"""Tests d'intégration Joyce : Ollama est simulé, aucun service externe requis."""
import json, os, subprocess, sys, tempfile, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BINARY = Path(sys.argv[1]).resolve()
class FakeOllama(BaseHTTPRequestHandler):
    requests_seen = []
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        payload = json.loads(self.rfile.read(length).decode("utf-8"))
        type(self).requests_seen.append(payload)
        prompt = payload.get("messages", [])[-1].get("content", "")
        if "coach tactique Apex Legends" in prompt:
            answer = "TEST_COACH_OK — priorité : rester à couvert."
        elif "coach de progression Apex Legends" in prompt:
            answer = "TEST_BILAN_OK — exercice : travailler le placement."
        elif "coach personnel Apex Legends" in prompt:
            answer = "TEST_INSIGHTS_OK — priorité : stabiliser le placement."
        else:
            answer = "TEST_CHAT_OK — réponse simulée."
        data = json.dumps({"model": payload.get("model", "fake-model"), "message": {"role": "assistant", "content": answer}, "done": True}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    def log_message(self, *_): pass

def check(condition, message):
    if not condition: raise AssertionError(message)
    print(f"  [OK] {message}")

def run_app(commands, workdir, memory_path, api_url):
    env = os.environ.copy(); env["JOYCE_MEMORY_FILE"] = str(memory_path); env["JOYCE_API_URL"] = api_url; env["JOYCE_MODEL"] = "joyce-test-model"
    result = subprocess.run([str(BINARY)], input="\n".join(commands)+"\n", text=True, capture_output=True, cwd=workdir, env=env, timeout=30)
    if result.returncode != 0: raise AssertionError(f"Joyce code {result.returncode}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")
    return result.stdout, result.stderr

def main():
    if not BINARY.is_file(): raise SystemExit(f"Binaire introuvable : {BINARY}")
    server = ThreadingHTTPServer(("127.0.0.1", 0), FakeOllama)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    api_url = f"http://127.0.0.1:{server.server_port}/api/chat"
    try:
        with tempfile.TemporaryDirectory(prefix="joyce-tests-") as temp:
            workdir = Path(temp); memory_path = workdir / "data" / "test-memory.json"; journal_path = workdir / "data" / "joyce_matches.json"
            print("\n1/6 — Commandes de base et état Apex")
            out, _ = run_app(["/help", "/status", "/apex", "/quit"], workdir, memory_path, api_url)
            check("Commandes disponibles" in out and "/coach" in out, "l'aide liste les commandes principales")
            check("Modèle Ollama : joyce-test-model" in out, "le modèle configuré est affiché")
            check("non connectée" in out or "aucune source" in out.lower(), "Joyce n'invente pas de source d'observation Apex")
            print("\n2/6 — Profil persistant et validation")
            out, _ = run_app(["/profil-set main_legend Wraith", "/profil-set goals Améliorer le placement en fin de partie", "/profil-set champ_interdit valeur", "/profil", "/quit"], workdir, memory_path, api_url)
            profile = json.loads(memory_path.read_text(encoding="utf-8"))["profile"]
            check(profile.get("main_legend") == "Wraith", "la légende principale est enregistrée")
            check(profile.get("goals") == "Améliorer le placement en fin de partie", "les valeurs de profil avec espaces sont conservées")
            check("Champ non autorisé" in out and "champ_interdit" not in profile, "un champ de profil non autorisé est refusé")
            print("\n3/6 — Coaching et conversation via une API simulée")
            out, _ = run_app(["/coach deux escouades nous poussent, derrière un rocher, zone qui ferme", "Bonjour Joyce", "/quit"], workdir, memory_path, api_url)
            check("TEST_COACH_OK" in out, "la commande /coach reçoit la réponse de l'API")
            check("TEST_CHAT_OK" in out, "la conversation standard reçoit une réponse")
            mem = json.loads(memory_path.read_text(encoding="utf-8"))
            check(any(m.get("role") == "assistant" and "TEST_CHAT_OK" in m.get("content", "") for m in mem["messages"]), "les échanges sont sauvegardés")
            print("\n4/6 — Fiche de partie, notes, statistiques et persistance")
            out, _ = run_app(["/partie nouvelle Wraith", "/note Deux équipes nous contestent derrière un rocher", "/fin 2 850 4", "/stats", "/quit"], workdir, memory_path, api_url)
            journal = json.loads(journal_path.read_text(encoding="utf-8")); check(len(journal["sessions"]) == 1, "la partie terminée est enregistrée")
            session = journal["sessions"][0]
            check(session.get("legend") == "Wraith" and session.get("kills") == 2 and session.get("damage") == 850 and session.get("placement") == 4, "légende, kills, dégâts et rang sont conservés")
            check(len(session.get("notes", [])) == 1 and "rocher" in session["notes"][0].get("text", ""), "la note de partie est sauvegardée")
            check("Parties enregistrées : 1" in out and "Total éliminations : 2" in out, "les statistiques affichent les valeurs enregistrées")
            print("\n5/6 — Bilan, redémarrage et réinitialisation ciblée")
            out, _ = run_app(["/bilan", "/reset", "/profil", "/status", "/quit"], workdir, memory_path, api_url)
            check("TEST_BILAN_OK" in out, "le bilan utilise la réponse de l'API")
            mem = json.loads(memory_path.read_text(encoding="utf-8")); check(mem.get("messages") == [], "/reset efface l'historique de conversation")
            check(mem["profile"].get("main_legend") == "Wraith", "/reset conserve le profil")
            check("Parties enregistrées : 1" in out, "les fiches survivent au redémarrage et au reset")
            check(len(FakeOllama.requests_seen) >= 3, "les requêtes HTTP ont été envoyées à l'API simulée")
            print("\n6/6 — Insights personnalisés et import/export JSON")
            import_file = workdir / "provided_stats.json"
            import_file.write_text(json.dumps({"sessions": [{"legend": "Wraith", "kills": 3, "damage": 1200, "placement": 2}]}), encoding="utf-8")
            out, _ = run_app([f"/import-json {import_file}", "/stats", "/insights", f"/export-json {workdir / 'export.json'}", "/quit"], workdir, memory_path, api_url)
            imported_journal = json.loads(journal_path.read_text(encoding="utf-8"))
            check("1 partie(s) importée(s)" in out and len(imported_journal["sessions"]) == 2, "un fichier JSON fourni par l'utilisateur est importé")
            check("TEST_INSIGHTS_OK" in out, "les insights utilisent l'API et les données de progression")
            exported = json.loads((workdir / "export.json").read_text(encoding="utf-8"))
            check(len(exported["sessions"]) == 2, "le journal peut être exporté en JSON")
        print("\nSUCCÈS : tous les tests d'intégration Joyce sont passés.")
    finally: server.shutdown(); server.server_close()

if __name__ == "__main__":
    try: main()
    except Exception as exc:
        print(f"\nÉCHEC : {exc}", file=sys.stderr); raise
