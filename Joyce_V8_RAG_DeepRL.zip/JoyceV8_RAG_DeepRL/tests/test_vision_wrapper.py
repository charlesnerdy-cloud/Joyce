#!/usr/bin/env python3
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
WRAPPER = ROOT / "scripts" / "vision.py"


class VisionWrapperTests(unittest.TestCase):
    def test_help(self):
        result = subprocess.run(["python3", str(WRAPPER), "--help"], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("image ou vidéo locale", result.stdout)

    def test_missing_input_fails_before_build(self):
        result = subprocess.run(["python3", str(WRAPPER), "/file/qui/nexiste/pas.png"], text=True, capture_output=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("introuvable", result.stderr)

    def test_fake_engine_and_json_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            media = tmp / "sample.png"
            media.write_bytes(b"fake image; fake engine does not decode it")
            engine = tmp / "fake_engine.py"
            engine.write_text('''#!/usr/bin/env python3
import json, sys
from pathlib import Path
out = Path(sys.argv[sys.argv.index("--out") + 1])
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({"media_type":"image","frames_analyzed":1,"summary":{"mean_brightness_0_255":12.5,"mean_edge_density_percent":3.0,"significant_visual_changes":0}}))
print("fake engine ok")
''', encoding="utf-8")
            engine.chmod(0o755)
            report = tmp / "report.json"
            env = dict(os.environ, JOYCE_VISION_BIN=str(engine))
            result = subprocess.run(["python3", str(WRAPPER), str(media), "--out", str(report)],
                                    text=True, capture_output=True, env=env)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(report.is_file())
            self.assertIn("Résumé Python", result.stdout)
            self.assertIn("12.50/255", result.stdout)

    def test_invalid_sampling_interval(self):
        with tempfile.TemporaryDirectory() as tmp:
            media = Path(tmp) / "sample.png"
            media.write_bytes(b"placeholder")
            result = subprocess.run(["python3", str(WRAPPER), str(media), "--sample-seconds", "0"],
                                    text=True, capture_output=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("sample-seconds", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
