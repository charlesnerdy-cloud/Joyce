#!/usr/bin/env python3
"""Tests hors ligne du client d'interprétation Ollama."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("joyce_vision_coach", ROOT / "scripts" / "vision_coach.py")
COACH = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(COACH)

class FakeResponse:
    def __init__(self, payload): self.payload = payload
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self): return json.dumps(self.payload).encode()

class VisionCoachTests(unittest.TestCase):
    def setUp(self):
        self.answer = {"summary": "Changements visuels observés, événements inconnus.",
            "observations": ["Luminosité moyenne mesurée : 90/255."],
            "hypotheses": ["La scène peut avoir changé."], "confidence": 0.6,
            "recommendations": ["Examiner la séquence autour du changement."],
            "limitations": ["Aucune reconnaissance d'ennemi."]}

    def test_context_does_not_include_media_path(self):
        context = COACH.build_context({"media_path": "/secret/video.mp4", "media_type": "video",
            "frames_analyzed": 3, "summary": {"mean_brightness_0_255": 90}})
        self.assertNotIn("media_path", context)
        self.assertEqual(context["summary"]["mean_brightness_0_255"], 90)

    def test_validates_model_response(self):
        clean = COACH.validate_result(self.answer)
        self.assertEqual(clean["summary"], self.answer["summary"])
        with self.assertRaises(ValueError): COACH.validate_result({"summary": "nope"})

    def test_ollama_request_and_json_response(self):
        fake = {"message": {"content": json.dumps(self.answer)}}
        with patch.object(COACH.urllib.request, "urlopen", return_value=FakeResponse(fake)) as urlopen:
            result = COACH.ask_ollama({"frames_analyzed": 1}, api_url="http://localhost:11434/api/chat", model="qwen2.5:3b")
        self.assertEqual(result["summary"], self.answer["summary"])
        request = urlopen.call_args.args[0]
        self.assertEqual(request.get_method(), "POST")
        self.assertIn(b"qwen2.5:3b", request.data)

    def test_run_writes_analysis_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            report = Path(tmp) / "report.json"
            output = Path(tmp) / "analysis.json"
            report.write_text(json.dumps({"media_type": "image", "frames_analyzed": 1,
                "summary": {"mean_brightness_0_255": 42}, "limitations": ["no recognition"]}), encoding="utf-8")
            with patch.object(COACH, "ask_ollama", return_value=COACH.validate_result(self.answer)):
                result = COACH.run(report, output, "http://localhost:11434/api/chat", "qwen2.5:3b", 10)
            self.assertTrue(output.is_file())
            self.assertEqual(json.loads(output.read_text(encoding="utf-8"))["model"], "qwen2.5:3b")
            self.assertEqual(result["confidence"], 0.6)

if __name__ == "__main__": unittest.main(verbosity=2)
