import importlib.util, json, tempfile, unittest, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
SCRIPT=Path(__file__).resolve().parents[1]/'scripts'/'joyce_companion.py'
spec=importlib.util.spec_from_file_location('joyce_companion',SCRIPT); jc=importlib.util.module_from_spec(spec); spec.loader.exec_module(jc)
class CompanionTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.old=(jc.PROFILE,jc.EVENTS,jc.FEEDBACK)
  jc.PROFILE=Path(self.tmp.name)/'profile.json'; jc.EVENTS=Path(self.tmp.name)/'events.jsonl'; jc.FEEDBACK=Path(self.tmp.name)/'feedback.jsonl'
 def tearDown(self):
  jc.PROFILE,jc.EVENTS,jc.FEEDBACK=self.old; self.tmp.cleanup()
 def test_pin_auth_sets_local_ready(self):
  j=jc.Joyce(); pin=j.begin_session(); ok,msg=j.authenticate(pin)
  self.assertTrue(ok); self.assertEqual(j.state,'ready'); self.assertIn('local uniquement',msg)
 def test_wrong_pin_rejected(self):
  j=jc.Joyce(); j.begin_session(); ok,_=j.authenticate('wrong'); self.assertFalse(ok); self.assertEqual(j.state,'awaiting_pin')
 def test_memory_persists(self):
  j=jc.Joyce(); j.remember('legend','Wraith'); j.add_goal('meilleur placement')
  self.assertEqual(json.loads(jc.PROFILE.read_text())['preferences']['legend'],'Wraith')
 def test_feedback_saved(self):
  j=jc.Joyce(); j.feedback({'health':50},'take_cover','helpful','good')
  self.assertEqual(json.loads(jc.FEEDBACK.read_text())['result'],'helpful')
 def test_nn_coach_output(self):
  result=jc.get_nn_action({'health':20,'cover':0,'enemies':2}, str(Path(self.tmp.name)/'missing-model.json'))
  self.assertIn(result['action'],('take_cover','heal_or_recharge','regroup','reposition','engage'))
 def test_bad_state_rejected(self):
  with self.assertRaises(ValueError): jc.parse_state('[]')
if __name__=='__main__': unittest.main()
