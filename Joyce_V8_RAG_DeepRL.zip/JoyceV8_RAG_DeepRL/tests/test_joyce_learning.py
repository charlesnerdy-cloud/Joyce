import json, tempfile, unittest
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"scripts"))
import joyce_learning as jl
import teammate_nn as nn

class LearningTests(unittest.TestCase):
    def test_add_and_load(self):
        with tempfile.TemporaryDirectory() as td:
            old = jl.DATASET
            try:
                jl.DATASET = Path(td)/"examples.jsonl"
                jl.add_example({"health": 20, "shield": 10}, "heal_or_recharge", "reviewed")
                rows = jl.load_rows()
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["action"], "heal_or_recharge")
            finally:
                jl.DATASET = old

    def test_invalid_action_rejected(self):
        with self.assertRaises(ValueError):
            jl.add_example({}, "fly_to_moon")

    def test_split_is_reproducible(self):
        rows = [{"x":[0.0]*8,"y":0,"state":{},"action":"take_cover"} for _ in range(10)]
        a,b = jl.split_rows(rows, seed=7)
        c,d = jl.split_rows(rows, seed=7)
        self.assertEqual(len(a), len(c))
        self.assertEqual(len(b), len(d))

    def test_evaluate_report(self):
        model = nn.MLP()
        rows = [{"x": nn.vector({"health": 30}), "y": 0, "action":"take_cover", "state":{}}]
        result = jl.evaluate(model, rows)
        self.assertEqual(result["count"], 1)
        self.assertIn("accuracy", result)

if __name__ == "__main__":
    unittest.main()
