# Test rapide Joyce Vision V5.1

1. Installer les dépendances listées dans `INSTALLATION_FR.txt`.
2. Compiler avec `./scripts/build.sh`.
3. Exécuter `./scripts/test_all.sh`.
4. Tester une capture locale : `./scripts/vision.sh /chemin/capture.png --out data/test_vision.json`.
5. Tester une vidéo : `./scripts/vision.sh /chemin/partie.mp4 --sample-seconds 1 --out data/test_video.json`.
6. Vérifier que le JSON contient `frames_analyzed`, `summary` et `limitations`.

Les tests synthétiques vérifient les métriques de luminosité et de changement visuel. Ils ne mesurent pas la qualité de détection d'adversaires ou d'événements Apex.
