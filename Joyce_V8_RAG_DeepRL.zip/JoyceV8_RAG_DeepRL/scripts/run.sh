#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -x "$ROOT/build/joyce" ]]; then
  "$ROOT/scripts/build.sh"
fi
cd "$ROOT"
exec "$ROOT/build/joyce" "$@"
