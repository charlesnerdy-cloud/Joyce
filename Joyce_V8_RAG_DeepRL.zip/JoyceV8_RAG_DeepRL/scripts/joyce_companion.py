#!/usr/bin/env python3
"""Joyce V6 Companion: local session/PIN, persistent profile, feedback and NN advice.

This is a local companion shell. It deliberately does not connect to or control Apex,
read game memory, send in-game chat, join squads, or toggle the game's Ready button.
"""
from __future__ import annotations
import argparse, json, os, secrets, sys, time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
PROFILE = DATA / 'joyce_profile.json'
EVENTS = DATA / 'joyce_companion_events.jsonl'
FEEDBACK = DATA / 'joyce_feedback.jsonl'
PIN_TTL = 180


def now(): return datetime.now(timezone.utc).isoformat()
def load_json(path, default):
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        return data if isinstance(data, type(default)) else default
    except (OSError, json.JSONDecodeError): return default

def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    tmp.replace(path)

def append_jsonl(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f: f.write(json.dumps(data, ensure_ascii=False)+'\n')

class Joyce:
    def __init__(self, pin_ttl=PIN_TTL):
        self.profile=load_json(PROFILE, {'schema_version':1,'name':'Joyce','preferences':{},'goals':[], 'sessions':0, 'lessons':[]})
        self.state='starting'; self.pin=None; self.pin_deadline=0; self.pin_ttl=pin_ttl
        self.session_id=secrets.token_hex(6); self.last_state=None
        self.log('started', {'session_id':self.session_id})

    def log(self, event, extra=None):
        append_jsonl(EVENTS, {'at':now(),'event':event,'state':self.state,'session_id':self.session_id, **(extra or {})})

    def begin_session(self):
        self.state='awaiting_pin'; self.pin=f'{secrets.randbelow(1_000_000):06d}'; self.pin_deadline=time.monotonic()+self.pin_ttl
        self.log('pin_issued', {'expires_in_seconds':self.pin_ttl})
        # Requested behavior: PIN shown on stdout. Avoid shell transcripts/shared logs.
        print(f'\n[JOYCE] PIN de session : {self.pin}', flush=True)
        print(f'[JOYCE] Saisis ce PIN dans le terminal dans les {self.pin_ttl} secondes.', flush=True)
        return self.pin

    def authenticate(self, value):
        if self.state != 'awaiting_pin' or not self.pin: return False, 'Aucune authentification en attente.'
        if time.monotonic() > self.pin_deadline:
            self.pin=None; self.state='disconnected'; self.log('pin_expired')
            return False, 'PIN expiré : session annulée.'
        if not secrets.compare_digest(str(value).strip(), self.pin):
            self.log('pin_rejected')
            return False, 'PIN incorrect.'
        self.pin=None; self.state='connected'; self.profile['sessions']=int(self.profile.get('sessions',0))+1
        save_json(PROFILE,self.profile); self.log('authenticated')
        self.state='ready'; self.log('ready_local')
        return True, 'Authentification validée. État Joyce : CONNECTÉ puis PRÊT (état local uniquement).'

    def disconnect(self):
        self.pin=None; self.state='disconnected'; self.log('disconnected')

    def remember(self, key, value):
        if not key.strip(): raise ValueError('La clé ne peut pas être vide.')
        self.profile.setdefault('preferences',{})[key.strip()]=value.strip()
        save_json(PROFILE,self.profile); self.log('preference_saved',{'key':key.strip()})

    def add_goal(self, text):
        if not text.strip(): raise ValueError('L’objectif ne peut pas être vide.')
        self.profile.setdefault('goals',[]).append({'text':text.strip(),'created_at':now()})
        save_json(PROFILE,self.profile); self.log('goal_saved')

    def feedback(self, state, action, result, note=''):
        from teammate_nn import ACTIONS, vector
        if action not in ACTIONS: raise ValueError(f"Action inconnue. Choix : {', '.join(ACTIONS)}")
        if result not in ('helpful','unhelpful'): raise ValueError("Le résultat doit être helpful ou unhelpful.")
        row={'timestamp':now(),'state':state,'action':action,'result':result,'note':note[:1000], 'human_reviewed':True}
        append_jsonl(FEEDBACK,row)
        # Retain an explicit, reviewable lesson; never silently mutate weights from one click.
        self.profile.setdefault('lessons',[]).append({'timestamp':row['timestamp'],'action':action,'result':result,'note':row['note']})
        self.profile['lessons']=self.profile['lessons'][-500:]
        save_json(PROFILE,self.profile); self.log('feedback_saved',{'action':action,'result':result})

    def status(self):
        return {'state':self.state,'session_id':self.session_id,'sessions':self.profile.get('sessions',0),
                'preferences':self.profile.get('preferences',{}),'goals':self.profile.get('goals',[]),
                'reviewed_lessons':len(self.profile.get('lessons',[])),
                'apex_link':'not_connected; no game control implemented'}


def parse_state(raw):
    try: state=json.loads(raw)
    except json.JSONDecodeError as e: raise ValueError(f'JSON invalide : {e}')
    if not isinstance(state,dict): raise ValueError('L’état doit être un objet JSON.')
    return state

def get_nn_action(state, model_path=None):
    import teammate_nn as nn
    path=Path(model_path) if model_path else nn.DEFAULT_MODEL
    model=nn.MLP.load(path) if path.exists() else nn.MLP()
    x=nn.vector(state); idx,probs=model.predict(x)
    return {'action':nn.ACTIONS[idx], 'recommendation':nn.DESCRIPTIONS[nn.ACTIONS[idx]],
            'confidence':round(probs[idx],4),'probabilities':{a:round(v,4) for a,v in zip(nn.ACTIONS,probs)},
            'caveat':'Prototype expérimental; les états sont fournis par l’utilisateur et rien n’est envoyé au jeu.'}

def command_loop(args):
    joyce=Joyce(args.pin_ttl)
    print('Joyce V6 — compagnon local. Tape /help. Pas de connexion ni de contrôle d’Apex.', flush=True)
    joyce.begin_session()
    while True:
        try: line=input('toi > ').strip()
        except (EOFError, KeyboardInterrupt): print(); joyce.disconnect(); return 0
        if not line: continue
        if line in ('/quit','/exit'): joyce.disconnect(); print('[JOYCE] À bientôt.'); return 0
        if line=='/help':
            print('/pin <code> | /status | /remember <clé> <valeur> | /goal <objectif> | /coach <JSON état> | /feedback <JSON état> <action> <helpful|unhelpful> [note] | /observe <image> | /disconnect | /quit')
        elif line.startswith('/pin '):
            ok,msg=joyce.authenticate(line[5:]); print('[JOYCE] '+msg)
            if not ok and joyce.state=='disconnected': print('[JOYCE] Session terminée. Lance à nouveau Joyce pour recommencer.')
        elif line=='/status': print(json.dumps(joyce.status(),ensure_ascii=False,indent=2))
        elif line.startswith('/remember '):
            payload=line[len('/remember '):]
            if ' ' not in payload: print('Usage : /remember <clé> <valeur>'); continue
            k,v=payload.split(' ',1); joyce.remember(k,v); print('[JOYCE] Je retiendrai cette préférence localement.')
        elif line.startswith('/goal '): joyce.add_goal(line[6:]); print('[JOYCE] Objectif enregistré.')
        elif line.startswith('/coach '):
            result=get_nn_action(parse_state(line[7:]),args.model); print(json.dumps(result,ensure_ascii=False,indent=2))
            joyce.last_state=parse_state(line[7:])
        elif line.startswith('/feedback '):
            payload=line[len('/feedback '):]
            # Format: /feedback {JSON} action helpful [note]; JSON state must be first balanced object.
            if not payload.startswith('{'): print('Usage : /feedback {"health":35,...} take_cover helpful [note]'); continue
            depth=0; end=None; in_str=False; esc=False
            for i,ch in enumerate(payload):
                if ch=='"' and not esc: in_str=not in_str
                if not in_str:
                    if ch=='{': depth+=1
                    elif ch=='}':
                        depth-=1
                        if depth==0: end=i+1; break
                esc=(ch=='\\' and not esc)
                if ch!='\\': esc=False
            if end is None: print('État JSON incomplet.'); continue
            state=parse_state(payload[:end]); rest=payload[end:].strip().split(' ',2)
            if len(rest)<2: print('Usage : /feedback {JSON} action helpful|unhelpful [note]'); continue
            joyce.feedback(state,rest[0],rest[1],rest[2] if len(rest)>2 else ''); print('[JOYCE] Retour sauvegardé pour révision et entraînement futur.')
        elif line.startswith('/observe '):
            image=line[len('/observe '):].strip().strip('"')
            cmd=[sys.executable,str(ROOT/'scripts'/'vision_model.py'),image]
            if args.reason: cmd += ['--reason']
            import subprocess
            rc=subprocess.call(cmd)
            if rc: print('[JOYCE] Analyse impossible; vérifie Ollama et le modèle de vision.')
        elif line=='/disconnect': joyce.disconnect(); print('[JOYCE] Session locale terminée. Redémarre Joyce pour une nouvelle session.')
        else: print('Commande inconnue. Tape /help.')

def main():
    p=argparse.ArgumentParser(description='Joyce V6 — compagnon local, mémoire et NN expérimental')
    p.add_argument('--pin-ttl',type=int,default=PIN_TTL,help='durée de validité du PIN en secondes')
    p.add_argument('--model',help='chemin du modèle NN JSON')
    p.add_argument('--reason',action='store_true',help='activer le raisonnement texte lors de /observe')
    p.add_argument('--status',action='store_true',help='afficher le statut persistant sans session interactive')
    args=p.parse_args()
    if not 30 <= args.pin_ttl <= 900: p.error('--pin-ttl doit être entre 30 et 900 secondes')
    if args.status: print(json.dumps(Joyce(args.pin_ttl).status(),ensure_ascii=False,indent=2)); return 0
    try: return command_loop(args)
    except (OSError,ValueError,KeyError,TypeError) as e: print(f'[JOYCE] Erreur : {e}',file=sys.stderr); return 2
if __name__=='__main__': raise SystemExit(main())
