#!/usr/bin/env python3
"""Joyce NN teammate prototype: local tactical suggestions, never game input."""
from __future__ import annotations
import argparse, json, math, random, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL = ROOT / "data" / "joyce_policy_nn.json"
DEFAULT_HISTORY = ROOT / "data" / "joyce_teammate_history.jsonl"
FEATURES = ["health", "shield", "ammo", "enemies", "teammates_alive", "zone_pressure", "cover", "squad_distance"]
ACTIONS = ["take_cover", "heal_or_recharge", "regroup", "reposition", "engage"]
DESCRIPTIONS = {
    "take_cover": "Chercher/maintenir un couvert et réduire l'exposition.",
    "heal_or_recharge": "Se soigner ou recharger les boucliers dès qu'un créneau sûr existe.",
    "regroup": "Rejoindre les coéquipiers et éviter un duel isolé.",
    "reposition": "Se déplacer vers une position plus sûre ou un meilleur angle.",
    "engage": "Envisager un engagement seulement si l'équipe et les ressources le permettent.",
}

def clamp(v): return max(0.0, min(1.0, float(v)))
def vector(state):
    defaults = {"health": 1, "shield": 1, "ammo": 1, "enemies": 0, "teammates_alive": 1, "zone_pressure": 0, "cover": 1, "squad_distance": 0}
    vals = {**defaults, **state}
    # Accept natural units as well as normalized inputs.
    out=[]
    for k in FEATURES:
        x=float(vals[k])
        if k in ("health", "shield") and x > 1: x /= 100.0
        elif k == "ammo" and x > 1: x = min(1.0, x / 300.0)
        elif k == "enemies" and x > 1: x = min(1.0, x / 4.0)
        elif k == "teammates_alive" and x > 1: x = min(1.0, x / 3.0)
        elif k == "squad_distance" and x > 1: x = min(1.0, x / 100.0)
        out.append(clamp(x))
    return out

def heuristic(x):
    h,s,a,e,t,z,c,d=x
    if c < .25 or (e > .45 and h < .45): return 0
    if (h < .42 or s < .22) and c > .35: return 1
    if t < .5 or d > .55: return 2
    if z > .65 or (e > .6 and c < .5): return 3
    return 4

def starter_data(count=600, seed=17):
    rng=random.Random(seed); rows=[]
    for _ in range(count):
        x=[rng.random() for _ in FEATURES]
        # Starter labels are heuristic-generated; real training should use human-reviewed examples.
        y=heuristic(x)
        rows.append((x,y))
    return rows

def softmax(xs):
    m=max(xs); ex=[math.exp(max(-40.0, min(40.0, v-m))) for v in xs]; total=sum(ex)
    return [v/total for v in ex]

class MLP:
    def __init__(self, ni=8, nh=12, no=5, seed=42):
        r=random.Random(seed)
        self.w1=[[r.uniform(-.25,.25) for _ in range(ni)] for _ in range(nh)]
        self.b1=[0.0]*nh
        self.w2=[[r.uniform(-.25,.25) for _ in range(nh)] for _ in range(no)]
        self.b2=[0.0]*no
    def forward(self,x):
        h=[math.tanh(sum(w*v for w,v in zip(row,x))+b) for row,b in zip(self.w1,self.b1)]
        return h, softmax([sum(w*v for w,v in zip(row,h))+b for row,b in zip(self.w2,self.b2)])
    def predict(self,x):
        _,p=self.forward(x); i=max(range(len(p)),key=p.__getitem__); return i,p
    def train(self, rows, epochs=180, lr=.035):
        rng=random.Random(99); data=list(rows)
        for _ in range(epochs):
            rng.shuffle(data)
            for x,y in data:
                h,p=self.forward(x); dz=[v-(1.0 if i==y else 0.0) for i,v in enumerate(p)]
                oldw2=[row[:] for row in self.w2]
                for o in range(len(self.w2)):
                    for j in range(len(h)): self.w2[o][j]-=lr*dz[o]*h[j]
                    self.b2[o]-=lr*dz[o]
                dh=[(1-hj*hj)*sum(oldw2[o][j]*dz[o] for o in range(len(dz))) for j,hj in enumerate(h)]
                for j in range(len(self.w1)):
                    for k in range(len(x)): self.w1[j][k]-=lr*dh[j]*x[k]
                    self.b1[j]-=lr*dh[j]
    def save(self,path):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({"format":"joyce-mlp-v1","features":FEATURES,"actions":ACTIONS,"w1":self.w1,"b1":self.b1,"w2":self.w2,"b2":self.b2},indent=2),encoding="utf-8")
    @classmethod
    def load(cls,path):
        d=json.loads(path.read_text(encoding="utf-8"))
        if d.get("format")!="joyce-mlp-v1" or d.get("features")!=FEATURES or d.get("actions")!=ACTIONS: raise ValueError("Format de modèle incompatible")
        m=cls(); m.w1=d["w1"];m.b1=d["b1"];m.w2=d["w2"];m.b2=d["b2"]
        if len(m.w1)!=12 or len(m.w2)!=5: raise ValueError("Dimensions du modèle invalides")
        return m

def append_history(path, record):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("a",encoding="utf-8") as f: f.write(json.dumps(record,ensure_ascii=False)+"\n")

def main():
    p=argparse.ArgumentParser(description="Joyce NN — recommandations tactiques locales (sans pilotage du jeu)")
    p.add_argument("--state",help="JSON contenant health, shield, ammo, enemies, teammates_alive, zone_pressure, cover, squad_distance")
    p.add_argument("--train",help="JSONL d'exemples annotés: chaque ligne {state:{...}, action:'take_cover'}")
    p.add_argument("--epochs",type=int,default=180)
    p.add_argument("--model",default=str(DEFAULT_MODEL))
    p.add_argument("--history",default=str(DEFAULT_HISTORY))
    p.add_argument("--demo",action="store_true",help="entraîner une première politique et afficher une recommandation exemple")
    args=p.parse_args(); model_path=Path(args.model); history_path=Path(args.history)
    try:
        if args.train or args.demo or not model_path.exists():
            rows=starter_data()
            if args.train:
                custom=[]
                for n,line in enumerate(Path(args.train).read_text(encoding="utf-8").splitlines(),1):
                    if not line.strip(): continue
                    item=json.loads(line); action=item.get("action")
                    if action not in ACTIONS: raise ValueError(f"Action invalide ligne {n}: {action}")
                    custom.append((vector(item.get("state",{})),ACTIONS.index(action)))
                if not custom: raise ValueError("Le fichier d'entraînement ne contient aucun exemple")
                rows=custom
            model=MLP(); model.train(rows,epochs=max(1,min(args.epochs,2000))); model.save(model_path)
            print(f"Modèle NN local entraîné et sauvegardé : {model_path}")
            print(f"Exemples utilisés : {len(rows)} (les exemples de démarrage sont synthétiques, pas des données de parties réelles).")
        else: model=MLP.load(model_path)
        state=json.loads(Path(args.state).read_text(encoding="utf-8")) if args.state else {"health":35,"shield":20,"ammo":.55,"enemies":2,"teammates_alive":1,"zone_pressure":.45,"cover":.8,"squad_distance":.2}
        x=vector(state); idx,probs=model.predict(x); action=ACTIONS[idx]
        record={"timestamp":datetime.now(timezone.utc).isoformat(),"state":state,"features":dict(zip(FEATURES,x)),"action":action,"confidence":round(probs[idx],4),"probabilities":{a:round(v,4) for a,v in zip(ACTIONS,probs)},"source":"local_mlp_suggestion_only"}
        append_history(history_path,record)
        print(json.dumps({**record,"recommendation":DESCRIPTIONS[action],"caution":"Suggestion expérimentale : vérifier le contexte. Aucune commande n'est envoyée au jeu."},ensure_ascii=False,indent=2))
        return 0
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
        print(f"Erreur Joyce NN : {e}",file=sys.stderr); return 2
if __name__=="__main__": raise SystemExit(main())
