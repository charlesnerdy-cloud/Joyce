#!/usr/bin/env python3
"""Tableau de bord local en lecture seule pour les données Joyce.

N'écoute que sur 127.0.0.1 ; aucune dépendance externe ni transmission réseau.
"""
from __future__ import annotations
import html
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

HOST = "127.0.0.1"
PORT = int(os.environ.get("JOYCE_DASHBOARD_PORT", "8765"))


def load_data(path: str | Path) -> tuple[list[dict], dict | None, str | None]:
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return [], None, "Le journal JSON doit contenir un objet."
        sessions = raw.get("sessions", [])
        if not isinstance(sessions, list):
            return [], None, "Le champ sessions n'est pas une liste."
        safe_sessions = [item for item in sessions if isinstance(item, dict)]
        current = raw.get("current") if isinstance(raw.get("current"), dict) else None
        return safe_sessions, current, None
    except FileNotFoundError:
        return [], None, f"Journal introuvable : {path}. Enregistre une partie dans Joyce pour le créer."
    except (OSError, json.JSONDecodeError) as exc:
        return [], None, f"Lecture impossible : {exc}"


def _number(session: dict, key: str) -> float | None:
    value = session.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
        return None
    return float(value)


def _fmt(value: float | None, digits: int = 1) -> str:
    if value is None:
        return "—"
    return f"{value:.{digits}f}".replace(".", ",")


def render_dashboard(path: str | Path) -> str:
    sessions, current, warning = load_data(path)
    def mean(key: str) -> float | None:
        values = [v for s in sessions if (v := _number(s, key)) is not None]
        return sum(values) / len(values) if values else None

    wins = sum(1 for s in sessions if _number(s, "placement") == 1)
    top5 = sum(1 for s in sessions if (_number(s, "placement") or 99) <= 5)
    legends: dict[str, int] = {}
    for session in sessions:
        legend = session.get("legend")
        if isinstance(legend, str) and legend.strip():
            legends[legend.strip()] = legends.get(legend.strip(), 0) + 1
    legend_text = ", ".join(f"{html.escape(k)} ({v})" for k, v in sorted(legends.items(), key=lambda pair: (-pair[1], pair[0]))) or "Aucune donnée"

    rows = []
    for session in reversed(sessions[-50:]):
        legend = html.escape(str(session.get("legend") or "Inconnue"))
        date = html.escape(str(session.get("ended_at") or session.get("date") or session.get("started_at") or "Date inconnue"))
        kills = _fmt(_number(session, "kills"), 0)
        damage = _fmt(_number(session, "damage"), 0)
        placement = _fmt(_number(session, "placement"), 0)
        notes_value = session.get("notes", [])
        note_count = len(notes_value) if isinstance(notes_value, list) else 0
        rows.append(f"<tr><td>{date}</td><td>{legend}</td><td>{kills}</td><td>{damage}</td><td>{placement}</td><td>{note_count}</td></tr>")
    if not rows:
        rows.append('<tr><td colspan="6" class="empty">Aucune partie enregistrée pour le moment.</td></tr>')
    warning_html = f'<p class="warning">{html.escape(warning)}</p>' if warning else ""
    current_html = "Aucune partie en cours"
    if current:
        current_html = f"Partie en cours : {html.escape(str(current.get('legend') or 'Légende inconnue'))} — début {html.escape(str(current.get('started_at') or 'inconnu'))}"
    analysis_path = Path(os.environ.get("JOYCE_VISION_ANALYSIS_FILE", str(Path(path).parent / "joyce_vision_analysis.json")))
    vision_html = '<p class="muted">Aucune interprétation visuelle disponible. Lance scripts/vision.py avec --coach.</p>'
    try:
        vision = json.loads(analysis_path.read_text(encoding="utf-8"))
        if isinstance(vision, dict):
            vsummary = html.escape(str(vision.get("summary") or "Résumé indisponible"))
            confidence = vision.get("confidence")
            confidence_text = f"{float(confidence):.0%}" if isinstance(confidence, (int, float)) and not isinstance(confidence, bool) and 0 <= confidence <= 1 else "non précisée"
            def safe_list(key: str) -> str:
                values = vision.get(key, [])
                if not isinstance(values, list):
                    return '<li>Données indisponibles</li>'
                return ''.join(f"<li>{html.escape(str(item))}</li>" for item in values if isinstance(item, str)) or '<li>Aucun élément fourni</li>'
            vision_html = f'<p><strong>Résumé :</strong> {vsummary}</p><p><strong>Confiance déclarée :</strong> {html.escape(confidence_text)} — estimation du modèle, pas une probabilité vérifiée.</p><h3>Observations</h3><ul>{safe_list("observations")}</ul><h3>Hypothèses</h3><ul>{safe_list("hypotheses")}</ul><h3>Recommandations</h3><ul>{safe_list("recommendations")}</ul><p class="muted">Les métriques OpenCV ne reconnaissent pas à elles seules les ennemis ou les événements Apex.</p>'
    except (OSError, json.JSONDecodeError):
        pass
    return f'''<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="30"><title>Joyce — Tableau de bord local</title>
<style>
:root{{color-scheme:dark;--bg:#10131b;--panel:#191e2a;--line:#30384b;--text:#edf1fa;--muted:#aab4c8;--accent:#8e9cff}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,sans-serif}}main{{max-width:1100px;margin:auto;padding:28px 18px 50px}}h1{{margin:0;font-size:clamp(1.7rem,4vw,2.5rem)}}h2{{font-size:1.1rem;margin-top:0}}p,.muted{{color:var(--muted)}}.top{{display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:20px}}.pill{{border:1px solid var(--line);border-radius:999px;padding:6px 11px;color:var(--muted);font-size:.85rem}}.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:18px 0}}.card,section{{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:18px}}.metric{{font-size:1.8rem;font-weight:750;color:var(--accent)}}.label{{font-size:.9rem;color:var(--muted)}}.table-wrap{{overflow-x:auto}}table{{width:100%;border-collapse:collapse;white-space:nowrap}}th,td{{padding:11px 12px;text-align:left;border-bottom:1px solid var(--line)}}th{{color:var(--muted);font-weight:600}}.empty{{text-align:center;color:var(--muted);padding:28px}}.warning{{background:#3a2c16;border:1px solid #71572a;border-radius:10px;padding:12px;color:#ffe1a1}}footer{{margin-top:18px;font-size:.88rem;color:var(--muted)}}
</style></head><body><main><div class="top"><div><h1>Joyce <span style="color:var(--accent)">/</span> Tableau de bord</h1><p>Analyse locale de tes fiches saisies ou importées.</p></div><span class="pill">Lecture seule · actualisation 30 s</span></div>
{warning_html}<div class="cards">
<div class="card"><div class="label">Parties enregistrées</div><div class="metric">{len(sessions)}</div></div>
<div class="card"><div class="label">Éliminations moyennes</div><div class="metric">{_fmt(mean('kills'), 2)}</div></div>
<div class="card"><div class="label">Dégâts moyens</div><div class="metric">{_fmt(mean('damage'), 0)}</div></div>
<div class="card"><div class="label">Rang moyen</div><div class="metric">{_fmt(mean('placement'), 2)}</div></div>
<div class="card"><div class="label">Top 5 / Victoires</div><div class="metric">{top5} / {wins}</div></div>
</div><section style="margin-bottom:16px"><h2>Légendes jouées</h2><p>{legend_text}</p><p>{current_html}</p></section>
<section style="margin-bottom:16px"><h2>Dernière analyse visuelle + Ollama</h2>{vision_html}</section>
<section><h2>Parties récentes</h2><div class="table-wrap"><table><thead><tr><th>Date</th><th>Légende</th><th>Éliminations</th><th>Dégâts</th><th>Rang</th><th>Notes</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
<footer>Les statistiques reflètent uniquement le fichier local Joyce. Les champs absents ne sont pas devinés. Cette page ne se connecte pas à Apex et n'envoie aucune donnée à Internet.</footer></main></body></html>'''


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ("/", "/healthz"):
            self.send_error(404)
            return
        if self.path == "/healthz":
            body = b"ok\n"
            content_type = "text/plain; charset=utf-8"
        else:
            path = os.environ.get("JOYCE_MATCHES_FILE", "data/joyce_matches.json")
            body = render_dashboard(path).encode("utf-8")
            content_type = "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        print("[Joyce Dashboard] " + (fmt % args))


def main() -> None:
    path = os.environ.get("JOYCE_MATCHES_FILE", "data/joyce_matches.json")
    print(f"Journal utilisé : {Path(path).resolve()}")
    print(f"Tableau de bord local : http://{HOST}:{PORT}")
    print("Arrêt : Ctrl+C. Serveur accessible uniquement depuis cette machine.")
    HTTPServer((HOST, PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
