#!/usr/bin/env python3
"""Joyce V7: reviewed-example dataset, holdout evaluation, controlled local training."""
from __future__ import annotations
import argparse, json, random, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATASET = DATA / "joyce_reviewed_examples.jsonl"
MODEL = DATA / "joyce_policy_nn.json"
ACTIONS = ("take_cover", "heal_or_recharge", "regroup", "reposition", "engage")

def now():
    return datetime.now(timezone.utc).isoformat()

def load_rows(path=None):
    import teammate_nn as nn
    if path is None:
        path = DATASET
    rows = []
    if not path.exists():
        return rows
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
            state, action = item["state"], item["action"]
            if not isinstance(state, dict) or action not in ACTIONS:
                raise ValueError("state/action invalide")
            rows.append({"state": state, "action": action, "x": nn.vector(state),
                         "y": ACTIONS.index(action), "reviewed_at": item.get("reviewed_at")})
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Exemple invalide ligne {line_no}: {exc}") from exc
    return rows

def add_example(state, action, note=""):
    import teammate_nn as nn
    if action not in ACTIONS:
        raise ValueError("Action inconnue. Choix : " + ", ".join(ACTIONS))
    if not isinstance(state, dict):
        raise ValueError("L’état doit être un objet JSON.")
    # Validate feature conversion before saving.
    nn.vector(state)
    DATASET.parent.mkdir(parents=True, exist_ok=True)
    item = {"reviewed_at": now(), "state": state, "action": action,
            "note": str(note)[:1000], "source": "human_reviewed"}
    with DATASET.open("a", encoding="utf-8") as f:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")
    return item

def split_rows(rows, seed=23, test_fraction=0.2):
    data = list(rows)
    random.Random(seed).shuffle(data)
    if len(data) < 5:
        return data, []
    n_test = max(1, min(len(data)-1, round(len(data)*test_fraction)))
    return data[n_test:], data[:n_test]

def evaluate(model, rows):
    import teammate_nn as nn
    if not rows:
        return {"count": 0, "accuracy": None, "message": "Pas assez d'exemples pour un test indépendant (minimum 5)."}
    correct = 0
    per_class = {a: {"count": 0, "correct": 0} for a in ACTIONS}
    for row in rows:
        pred, probs = model.predict(row["x"])
        actual = row["y"]
        per_class[ACTIONS[actual]]["count"] += 1
        if pred == actual:
            correct += 1
            per_class[ACTIONS[actual]]["correct"] += 1
    for val in per_class.values():
        val["accuracy"] = round(val["correct"]/val["count"], 3) if val["count"] else None
    return {"count": len(rows), "correct": correct, "accuracy": round(correct/len(rows), 4),
            "per_class": per_class,
            "caveat": "Le jeu de test est petit et les résultats ne garantissent pas la qualité en situation réelle."}

def main():
    p = argparse.ArgumentParser(description="Joyce V7 — mémoire d'exemples annotés et apprentissage contrôlé")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add", help="ajouter un exemple humainement annoté")
    a.add_argument("--state", required=True, help='JSON, ex. \'{"health":30,"shield":15,"cover":0.8}\'')
    a.add_argument("--action", required=True, choices=ACTIONS)
    a.add_argument("--note", default="")
    tr = sub.add_parser("train", help="entraîner sur les exemples annotés")
    tr.add_argument("--epochs", type=int, default=250)
    tr.add_argument("--test-fraction", type=float, default=0.2)
    ev = sub.add_parser("evaluate", help="évaluer le modèle existant sur des exemples annotés")
    st = sub.add_parser("stats", help="statistiques du jeu de données")
    args = p.parse_args()
    try:
        if args.cmd == "add":
            state = json.loads(args.state)
            add_example(state, args.action, args.note)
            print(f"Exemple annoté enregistré dans {DATASET}")
            return 0
        rows = load_rows()
        counts = {action: sum(1 for r in rows if r["action"] == action) for action in ACTIONS}
        if args.cmd == "stats":
            print(json.dumps({"dataset": str(DATASET), "total": len(rows), "actions": counts}, ensure_ascii=False, indent=2))
            return 0
        if args.cmd == "evaluate":
            if not MODEL.exists():
                raise ValueError("Modèle absent. Lance d'abord scripts/teammate_nn.py --demo ou la commande train.")
            import teammate_nn as nn
            model = nn.MLP.load(MODEL)
            _, test = split_rows(rows)
            print(json.dumps(evaluate(model, test), ensure_ascii=False, indent=2))
            return 0
        if len(rows) < 5:
            raise ValueError(f"Il faut au moins 5 exemples annotés (actuellement {len(rows)}).")
        if not 0.1 <= args.test_fraction <= 0.4:
            raise ValueError("--test-fraction doit être compris entre 0.1 et 0.4.")
        train_rows, test_rows = split_rows(rows, test_fraction=args.test_fraction)
        import teammate_nn as nn
        model = nn.MLP()
        model.train([(r["x"], r["y"]) for r in train_rows], epochs=max(1, min(args.epochs, 2000)))
        report = evaluate(model, test_rows)
        # Save only after a valid training run; report exact provenance.
        model.save(MODEL)
        report.update({"trained_examples": len(train_rows), "dataset_examples": len(rows),
                       "class_counts": counts, "model": str(MODEL),
                       "training_source": "human-reviewed examples only",
                       "note": "Le modèle a été entraîné sur une partition et évalué sur une partition tenue à l'écart."})
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"Erreur Joyce V7 : {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
