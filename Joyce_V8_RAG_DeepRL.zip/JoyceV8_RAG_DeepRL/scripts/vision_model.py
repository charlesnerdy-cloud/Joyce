#!/usr/bin/env python3
"""Vision multimodale locale via Ollama, historique JSONL et mode dossier."""
from __future__ import annotations
import argparse, base64, hashlib, json, os, sys, time, urllib.error, urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
API = os.environ.get('JOYCE_API_URL', 'http://localhost:11434/api/chat')
VISION_MODEL = os.environ.get('JOYCE_VISION_MODEL', 'qwen2.5vl:3b')
TEXT_MODEL = os.environ.get('JOYCE_MODEL', 'qwen2.5:3b')
HISTORY = Path(os.environ.get('JOYCE_VISION_HISTORY', ROOT / 'data/joyce_vision_history.jsonl'))
IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp'}
VIDEO_EXTS = {'.mp4', '.mkv', '.mov', '.avi', '.webm'}

VISION_PROMPT = '''Tu es Joyce, assistant d'analyse visuelle prudent pour un joueur. Décris seulement les éléments réellement visibles dans cette image. Distingue observations et interprétations; ne prétends pas être certain si l'image est floue ou ambiguë. N'invente ni position exacte, ni ennemi, ni objet que tu ne peux pas voir. Réponds en français, avec un résumé concis, les observations visibles, les incertitudes et une suggestion prudente. Il s'agit d'analyse uniquement : ne commande pas le jeu.'''
REASON_PROMPT = '''Tu es Joyce, assistant d'analyse. À partir de l'observation visuelle ci-dessous, formule un conseil de jeu prudent et concis. Sépare faits visibles et hypothèses. Ne prétends pas que l'observation est garantie et ne demande jamais d'automatiser les commandes du jeu. Réponds en français avec summary, facts, hypotheses, recommendations, limitations en JSON.'''

def _post(payload: dict, timeout: float) -> dict:
    req = urllib.request.Request(API, data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as res:
            data = json.loads(res.read().decode('utf-8'))
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f'Ollama inaccessible ou réponse illisible ({API}) : {exc}') from exc
    if not isinstance(data, dict) or not isinstance(data.get('message'), dict) or not isinstance(data['message'].get('content'), str):
        raise RuntimeError('Réponse Ollama inattendue : contenu du message absent.')
    return data

def _chat(model: str, messages: list[dict], timeout: float, json_mode: bool = False) -> str:
    payload = {'model': model, 'stream': False, 'messages': messages, 'options': {'temperature': 0.2}}
    if json_mode: payload['format'] = 'json'
    return _post(payload, timeout)['message']['content']

def _image_bytes(path: Path) -> bytes:
    if path.suffix.lower() not in IMAGE_EXTS: raise RuntimeError(f'Format image non pris en charge : {path.suffix}')
    try: data = path.read_bytes()
    except OSError as exc: raise RuntimeError(f'Lecture impossible pour {path}: {exc}') from exc
    if not data: raise RuntimeError(f'Image vide : {path}')
    if len(data) > 20 * 1024 * 1024: raise RuntimeError('Image supérieure à 20 Mio; réduis-la avant analyse.')
    return data

def _frames(video: Path, every: float, max_frames: int):
    try: import cv2
    except ImportError as exc: raise RuntimeError('Analyse vidéo : installe OpenCV Python (python3-opencv).') from exc
    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened(): raise RuntimeError(f'Vidéo impossible à ouvrir : {video}')
    fps = cap.get(cv2.CAP_PROP_FPS) or 0
    frame_count = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    duration = frame_count / fps if fps > 0 else None
    step = max(1, round(fps * every)) if fps > 0 else 1
    frames = []
    idx = 0
    try:
        while len(frames) < max_frames:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, frame = cap.read()
            if not ok: break
            ok, encoded = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
            if ok: frames.append((idx / fps if fps > 0 else float(idx), encoded.tobytes()))
            idx += step
    finally: cap.release()
    if not frames: raise RuntimeError(f'Aucune image décodable dans {video}')
    return frames, duration

def _describe(image: bytes, prompt: str, model: str, timeout: float) -> str:
    return _chat(model, [{'role':'user','content':prompt,'images':[base64.b64encode(image).decode('ascii')]}], timeout)

def _reason(observation: str, model: str, timeout: float) -> dict | None:
    if not model: return None
    raw = _chat(model, [{'role':'system','content':REASON_PROMPT},{'role':'user','content':observation}], timeout, True)
    try: parsed = json.loads(raw)
    except json.JSONDecodeError: return {'raw_response': raw, 'parse_warning':'Le modèle texte n’a pas renvoyé du JSON valide.'}
    return parsed if isinstance(parsed, dict) else {'raw_response':raw, 'parse_warning':'JSON non objet.'}

def _record(source: str, timestamp: float | None, data: bytes, vision_model: str, text_model: str | None, timeout: float, reason: bool) -> dict:
    observation = _describe(data, VISION_PROMPT, vision_model, timeout)
    analysis = _reason(observation, text_model, timeout) if reason and text_model else None
    return {'schema_version':1, 'created_at':datetime.now(timezone.utc).isoformat(), 'source':source,
            'video_timestamp_seconds':timestamp, 'sha256':hashlib.sha256(data).hexdigest(),
            'vision_model':vision_model, 'observation':observation, 'reasoning_model':text_model if analysis is not None else None,
            'reasoning':analysis, 'limitations':['Sortie générée par IA : des erreurs de perception sont possibles.',
            'Aucun contrôle du jeu ni interaction avec le processus du jeu.']}

def append_history(item: dict, history: Path) -> None:
    history.parent.mkdir(parents=True, exist_ok=True)
    with history.open('a', encoding='utf-8') as f: f.write(json.dumps(item, ensure_ascii=False) + '\n')

def analyze(path: Path, every: float, max_frames: int, vision_model: str, text_model: str | None, timeout: float, reason: bool, history: Path) -> list[dict]:
    if not path.exists(): raise RuntimeError(f'Fichier introuvable : {path}')
    records = []
    if path.is_dir(): raise RuntimeError('Le chemin est un dossier; utilise --watch pour le surveiller.')
    if path.suffix.lower() in IMAGE_EXTS:
        records.append(_record(str(path), None, _image_bytes(path), vision_model, text_model, timeout, reason))
    elif path.suffix.lower() in VIDEO_EXTS:
        frames, duration = _frames(path, every, max_frames)
        for ts, data in frames:
            item = _record(str(path), ts, data, vision_model, text_model, timeout, reason)
            item['video_duration_seconds'] = duration
            records.append(item)
    else: raise RuntimeError(f'Format non pris en charge : {path.suffix}')
    for item in records: append_history(item, history)
    return records

def _watch(folder: Path, args) -> int:
    if not folder.is_dir(): raise RuntimeError(f'Dossier de surveillance introuvable : {folder}')
    seen: dict[str, tuple[int,int]] = {}
    print(f'Surveillance locale : {folder} (Ctrl+C pour arrêter)')
    while True:
        for path in sorted(folder.iterdir()):
            if not path.is_file() or path.suffix.lower() not in IMAGE_EXTS: continue
            try: st = path.stat()
            except OSError: continue
            signature = (st.st_size, st.st_mtime_ns)
            if seen.get(str(path)) == signature: continue
            # Attend que la capture finisse d'être écrite.
            time.sleep(min(args.settle, 5.0))
            try:
                st2 = path.stat()
                if (st2.st_size, st2.st_mtime_ns) != signature: continue
                results = analyze(path, args.sample_seconds, args.max_frames, args.vision_model,
                                  args.text_model if args.reason else None, args.timeout, args.reason, args.history)
                seen[str(path)] = signature
                print(f'\n[{results[0]["created_at"]}] {path.name}\n{results[0]["observation"]}\n')
            except (OSError, RuntimeError) as exc: print(f'Avertissement {path.name}: {exc}', file=sys.stderr)
        time.sleep(args.poll)

def main(argv=None) -> int:
    p = argparse.ArgumentParser(description='Vision multimodale locale Joyce via Ollama')
    p.add_argument('source', type=Path, help='Capture image, vidéo, ou dossier avec --watch')
    p.add_argument('--sample-seconds', type=float, default=2.0, help='Intervalle vidéo en secondes')
    p.add_argument('--max-frames', type=int, default=12, help='Nombre maximal de frames analysées')
    p.add_argument('--vision-model', default=VISION_MODEL)
    p.add_argument('--text-model', default=TEXT_MODEL)
    p.add_argument('--no-reason', action='store_true', help='Désactive le second passage avec le modèle texte')
    p.add_argument('--reason', action='store_true', help='Croise la description avec le modèle texte qwen2.5:3b')
    p.add_argument('--timeout', type=float, default=120.0)
    p.add_argument('--history', type=Path, default=HISTORY)
    p.add_argument('--watch', action='store_true', help='Surveille un dossier de captures')
    p.add_argument('--poll', type=float, default=1.0, help='Intervalle de vérification du dossier')
    p.add_argument('--settle', type=float, default=0.3, help='Délai avant lecture des nouvelles captures')
    args = p.parse_args(argv)
    if args.sample_seconds <= 0 or args.max_frames < 1 or args.timeout <= 0 or args.poll <= 0 or args.settle < 0: p.error('Les intervalles et limites doivent être positifs (settle peut être nul).')
    args.history = args.history.expanduser().resolve()
    try:
        if args.watch: return _watch(args.source.expanduser().resolve(), args)
        records = analyze(args.source.expanduser().resolve(), args.sample_seconds, args.max_frames,
                          args.vision_model, args.text_model if args.reason else None, args.timeout, args.reason, args.history)
    except KeyboardInterrupt: print('\nSurveillance arrêtée.'); return 0
    except RuntimeError as exc: print(f'Erreur Joyce Vision : {exc}', file=sys.stderr); return 1
    for i, item in enumerate(records, 1):
        stamp = f' à {item["video_timestamp_seconds"]:.2f}s' if item['video_timestamp_seconds'] is not None else ''
        print(f'\n--- Observation {i}/{len(records)}{stamp} ---\n{item["observation"]}')
        if item['reasoning'] is not None: print('\n--- Analyse croisée qwen ---\n' + json.dumps(item['reasoning'], ensure_ascii=False, indent=2))
    print(f'\nHistorique local : {args.history}')
    return 0

if __name__ == '__main__': raise SystemExit(main())
