#!/usr/bin/env python3
"""Python wrapper for Joyce's C++/OpenCV vision analyzer.

This wrapper validates inputs, builds the native analyzer on demand, invokes it,
then reads the generated JSON report to provide a concise summary. It never
captures live gameplay or sends input to the game.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_REPORT = ROOT / "data" / "joyce_vision_report.json"


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Analyse une image ou une vidéo locale d'Apex via le moteur C++ Joyce.",
        epilog="Exemple : python3 scripts/vision.py capture.mp4 --sample-seconds 1.5",
    )
    p.add_argument("input", type=Path, help="Chemin d'une image ou vidéo locale")
    p.add_argument("--out", type=Path, default=DEFAULT_REPORT, help="Chemin du rapport JSON")
    p.add_argument("--sample-seconds", type=float, default=1.0,
                   help="Intervalle d'échantillonnage vidéo (défaut : 1 seconde)")
    p.add_argument("--no-summary", action="store_true", help="Ne pas afficher le résumé JSON après l'analyse")
    p.add_argument("--coach", action="store_true", help="Demander une interprétation prudente au modèle Ollama local")
    p.add_argument("--analysis-out", type=Path, default=ROOT / "data" / "joyce_vision_analysis.json", help="Chemin du rapport d'interprétation Ollama")
    p.add_argument("--model", default=os.environ.get("JOYCE_MODEL", "qwen2.5:3b"), help="Modèle Ollama pour --coach")
    p.add_argument("--api-url", default=os.environ.get("JOYCE_API_URL", "http://localhost:11434/api/chat"), help="URL Ollama pour --coach")
    p.add_argument("--timeout", type=float, default=90.0, help="Délai maximal Ollama en secondes")
    return p


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    input_path = args.input.expanduser().resolve()
    output_path = args.out.expanduser().resolve()

    if not input_path.is_file():
        print(f"Erreur : fichier introuvable ou non régulier : {input_path}", file=sys.stderr)
        return 2
    if not (0 < args.sample_seconds <= 3600):
        print("Erreur : --sample-seconds doit être strictement positif et inférieur ou égal à 3600.", file=sys.stderr)
        return 2

    binary_override = os.environ.get("JOYCE_VISION_BIN")
    binary = Path(binary_override).expanduser().resolve() if binary_override else ROOT / "build" / "joyce_vision"
    if not binary.is_file() or not os.access(binary, os.X_OK):
        build_script = ROOT / "scripts" / "build.sh"
        print("Moteur C++ absent : compilation de Joyce Vision...", flush=True)
        built = subprocess.run([str(build_script)], cwd=ROOT)
        if built.returncode != 0:
            print("Erreur : compilation impossible. Vérifie OpenCV et nlohmann-json.", file=sys.stderr)
            return built.returncode or 1
        if not binary.is_file() or not os.access(binary, os.X_OK):
            print(f"Erreur : binaire non trouvé après compilation : {binary}", file=sys.stderr)
            return 1

    output_path.parent.mkdir(parents=True, exist_ok=True)
    command = [str(binary), str(input_path), "--out", str(output_path),
               "--sample-seconds", str(args.sample_seconds)]
    result = subprocess.run(command, cwd=ROOT)
    if result.returncode != 0:
        return result.returncode

    report = None
    if not args.no_summary or args.coach:
        try:
            report = json.loads(output_path.read_text(encoding="utf-8"))
            if not args.no_summary:
                summary = report.get("summary", {})
                print("\nRésumé Python de Joyce :")
                print(f"  Type de média : {report.get('media_type', 'inconnu')}")
                print(f"  Images analysées : {report.get('frames_analyzed', 0)}")
                print(f"  Luminosité moyenne : {summary.get('mean_brightness_0_255', 0):.2f}/255")
                print(f"  Densité moyenne des contours : {summary.get('mean_edge_density_percent', 0):.2f} %")
                print(f"  Changements visuels significatifs : {summary.get('significant_visual_changes', 0)}")
                print(f"  Rapport JSON : {output_path}")
                print("  Attention : ces mesures ne reconnaissent pas les adversaires ni les événements du jeu.")
        except (OSError, ValueError, TypeError) as exc:
            print(f"Avertissement : analyse terminée mais lecture du rapport impossible : {exc}", file=sys.stderr)
            return 1
    if args.coach:
        if args.timeout <= 0:
            print("Erreur : --timeout doit être strictement positif.", file=sys.stderr)
            return 2
        try:
            from vision_coach import run as coach_run
            result = coach_run(output_path, args.analysis_out.expanduser().resolve(), args.api_url, args.model, args.timeout)
        except (RuntimeError, ImportError) as exc:
            print(f"Erreur Coach Ollama : {exc}", file=sys.stderr)
            return 1
        print("\nInterprétation Ollama :")
        print(f"  {result['summary']}")
        for item in result["recommendations"]:
            print(f"  • {item}")
        print(f"  Analyse complète : {args.analysis_out.expanduser().resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
