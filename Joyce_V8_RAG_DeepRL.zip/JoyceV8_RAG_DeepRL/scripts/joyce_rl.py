#!/usr/bin/env python3
"""Joyce reward learner: learns from explicitly recorded state/action/outcome events."""
from __future__ import annotations
import argparse, json, math, random, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
EXPERIENCES = DATA / "joyce_rl_experiences.jsonl"
MODEL_PATH = DATA / "joyce_reward_model.json"
FEATURES = ["health", "shield", "ammo", "enemies", "teammates_alive", "zone_pressure", "cover", "squad_distance"]
ACTIONS = ["take_cover", "heal_or_recharge", "regroup", "reposition", "engage"]
EVENT_REWARDS = {
    "damage": (-1.0, "Dégâts subis : retour négatif."),
    "move_safe": (1.0, "Déplacement sans dégâts observés : retour positif."),
    "move_damage": (0.0, "Déplacement suivi de dégâts : résultat neutre, tester une autre direction."),
    "survive": (0.5, "Survie de l'intervalle observé : petit retour positif."),
    "downed": (-1.0, "Joueur mis à terre : retour négatif."),
    "objective": (0.7, "Objectif atteint : retour positif."),
    "manual_neutral": (0.0, "Retour neutre explicitement donné."),
}

def now(): return datetime.now(timezone.utc).isoformat()

def clamp(x, lo=-1.0, hi=1.0): return max(lo, min(hi, float(x)))

def state_vector(state):
    defaults = {"health":100,"shield":100,"ammo":100,"enemies":0,"teammates_alive":3,"zone_pressure":0,"cover":1,"squad_distance":0}
    v = {**defaults, **state}
    out=[]
    for k in FEATURES:
        x=float(v[k])
        if k in ("health","shield") and x > 1: x /= 100
        elif k=="ammo" and x>1: x=min(1,x/300)
        elif k=="enemies" and x>1: x=min(1,x/4)
        elif k=="teammates_alive" and x>1: x=min(1,x/3)
        elif k=="squad_distance" and x>1: x=min(1,x/100)
        out.append(max(0,min(1,x)))
    return out

def input_vector(state, action):
    if action not in ACTIONS: raise ValueError(f"Action inconnue: {action}")
    return state_vector(state)+[1.0 if a==action else 0.0 for a in ACTIONS]

def relu(x): return max(0.0,x)

class RewardMLP:
    """Small local MLP regressor; online SGD predicts expected outcome reward."""
    def __init__(self, ni=13, nh=16, seed=101):
        r=random.Random(seed)
        self.w1=[[r.uniform(-0.15,0.15) for _ in range(ni)] for _ in range(nh)]
        self.b1=[0.0]*nh
        self.w2=[r.uniform(-0.15,0.15) for _ in range(nh)]
        self.b2=0.0
        self.steps=0
    def forward(self,x):
        h=[math.tanh(sum(w*v for w,v in zip(row,x))+b) for row,b in zip(self.w1,self.b1)]
        y=math.tanh(sum(w*v for w,v in zip(self.w2,h))+self.b2)
        return h,y
    def predict(self,x): return self.forward(x)[1]
    def update(self,x,target,lr=0.015):
        h,y=self.forward(x)
        # MSE with tanh output derivative
        dy=2*(y-target)*(1-y*y)
        old_w2=self.w2[:]
        for j in range(len(self.w2)): self.w2[j]-=lr*dy*h[j]
        self.b2-=lr*dy
        for j,hj in enumerate(h):
            dh=dy*old_w2[j]*(1-hj*hj)
            for k,xk in enumerate(x): self.w1[j][k]-=lr*dh*xk
            self.b1[j]-=lr*dh
        self.steps+=1
        return (y-target)**2
    def save(self,path):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({"format":"joyce-reward-mlp-v1","features":FEATURES,"actions":ACTIONS,"w1":self.w1,"b1":self.b1,"w2":self.w2,"b2":self.b2,"steps":self.steps},indent=2),encoding="utf-8")
    @classmethod
    def load(cls,path):
        d=json.loads(path.read_text(encoding="utf-8"))
        if d.get("format")!="joyce-reward-mlp-v1" or d.get("features")!=FEATURES or d.get("actions")!=ACTIONS: raise ValueError("Format du modèle reward incompatible")
        m=cls()
        m.w1=d["w1"];m.b1=d["b1"];m.w2=d["w2"];m.b2=d["b2"];m.steps=int(d.get("steps",0))
        if len(m.w1)!=16 or len(m.w2)!=16: raise ValueError("Dimensions du modèle invalides")
        return m

def append_record(path,record):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("a",encoding="utf-8") as f: f.write(json.dumps(record,ensure_ascii=False)+"\n")

def load_records(path=EXPERIENCES):
    if not path.exists(): return []
    rows=[]
    for n,line in enumerate(path.read_text(encoding="utf-8").splitlines(),1):
        if not line.strip(): continue
        try:
            r=json.loads(line)
            if r["action"] not in ACTIONS or r["event"] not in EVENT_REWARDS: raise ValueError("action/event inconnu")
            rows.append(r)
        except Exception as e: raise ValueError(f"Expérience invalide ligne {n}: {e}") from e
    return rows

def learn_record(record, model=None, epochs=12, lr=.015):
    model=model or (RewardMLP.load(MODEL_PATH) if MODEL_PATH.exists() else RewardMLP())
    x=input_vector(record["state"],record["action"]); reward=float(record["reward"])
    before=model.predict(x)
    losses=[]
    for _ in range(max(1,min(epochs,500))): losses.append(model.update(x,reward,lr))
    after=model.predict(x)
    model.save(MODEL_PATH)
    return model, {"prediction_before":round(before,4),"prediction_after":round(after,4),
                   "target_reward":reward,"training_steps":len(losses),"last_squared_error":round(losses[-1],5)}

def main():
    p=argparse.ArgumentParser(description="Joyce online reward learner — logs inputs, action, outcome and reward")
    sub=p.add_subparsers(dest="cmd",required=True)
    f=sub.add_parser("feedback",help="enregistrer un retour de situation et entraîner le modèle")
    f.add_argument("--state",required=True,help="état JSON observé avant l'action")
    f.add_argument("--action",required=True,choices=ACTIONS,help="action recommandée/essayée")
    f.add_argument("--event",required=True,choices=EVENT_REWARDS.keys(),help="résultat observé")
    f.add_argument("--note",default="")
    f.add_argument("--epochs",type=int,default=12)
    sub.add_parser("stats",help="résumé des expériences enregistrées")
    a=sub.add_parser("predict",help="prédire le retour estimé de chaque action pour un état")
    a.add_argument("--state",required=True)
    args=p.parse_args()
    try:
        if args.cmd=="feedback":
            state=json.loads(args.state); state_vector(state)
            reward,description=EVENT_REWARDS[args.event]
            record={"timestamp":now(),"state":state,"action":args.action,"event":args.event,
                    "reward":reward,"note":args.note[:1000],"source":"explicit_user_feedback"}
            append_record(EXPERIENCES,record)
            model,report=learn_record(record,epochs=args.epochs)
            print(json.dumps({"recorded":True,"event_description":description,"record":record,
                              "learning":report,"model":str(MODEL_PATH),"history":str(EXPERIENCES)},ensure_ascii=False,indent=2))
            return 0
        rows=load_records()
        if args.cmd=="stats":
            print(json.dumps({"experience_count":len(rows),"event_counts":{e:sum(r["event"]==e for r in rows) for e in EVENT_REWARDS},
                              "model_exists":MODEL_PATH.exists(),"model_steps":RewardMLP.load(MODEL_PATH).steps if MODEL_PATH.exists() else 0},ensure_ascii=False,indent=2))
            return 0
        state=json.loads(args.state); xstate=state_vector(state)
        model=RewardMLP.load(MODEL_PATH) if MODEL_PATH.exists() else RewardMLP()
        predictions={}
        for action in ACTIONS:
            predictions[action]=round(model.predict(xstate+[1.0 if a==action else 0.0 for a in ACTIONS]),4)
        best=max(predictions,key=predictions.get)
        print(json.dumps({"estimated_rewards":predictions,"highest_estimated_action":best,
                          "note":"Prédictions exploratoires, non validées pour le jeu réel."},ensure_ascii=False,indent=2))
        return 0
    except (OSError,ValueError,TypeError,json.JSONDecodeError) as e:
        print(f"Erreur Joyce RL : {e}",file=sys.stderr);return 2

if __name__=="__main__": raise SystemExit(main())
