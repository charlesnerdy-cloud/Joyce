#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage : $0 /chemin/vers/le/projet/Joyce" >&2
  exit 2
fi
SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="$(mkdir -p "$1" && cd "$1" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$TARGET/joyce_pre_v5_1_backup_$STAMP"
mkdir -p "$BACKUP"
# An old executable would otherwise let run.sh skip rebuilding; archive generated build output.
if [[ -e "$TARGET/build" ]]; then mv "$TARGET/build" "$BACKUP/build"; fi
for item in CMakeLists.txt README.md INSTALLATION_FR.txt include src scripts tests .gitignore; do
  if [[ -e "$TARGET/$item" ]]; then
    mkdir -p "$BACKUP"
    cp -a "$TARGET/$item" "$BACKUP/"
  fi
done
for item in CMakeLists.txt README.md INSTALLATION_FR.txt include src scripts tests .gitignore; do
  if [[ -e "$SOURCE/$item" ]]; then
    rm -rf "$TARGET/$item"
    cp -a "$SOURCE/$item" "$TARGET/$item"
  fi
done
# Preserve all user data; ensure the directory exists without overwriting it.
mkdir -p "$TARGET/data"
chmod +x "$TARGET/scripts/"*.sh
printf '\nJoyce V5.1 copiée vers : %s\nSauvegarde des fichiers remplacés : %s\nDonnées du dossier data/ préservées.\n\nÉtape suivante : cd "%s" && ./scripts/test_all.sh\n' "$TARGET" "$BACKUP" "$TARGET"
