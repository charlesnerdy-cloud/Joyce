#!/usr/bin/env python3
"""Joyce V8: local lexical RAG + offline Double-DQN prototype. No game I/O."""
from __future__ import annotations
import argparse, json, math, random, re, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data"
TRANSITIONS=DATA/"joyce_transitions.jsonl"
MODEL=DATA/"joyce_dqn.json"
ACTIONS=("take_cover","heal_or_recharge","regroup","reposition","engage")
FEATURES=("health","shield","ammo","enemies","teammates_alive","zone_pressure","cover","squad_distance")
DEFAULTS={"health":100,"shield":100,"ammo":100,"enemies":0,"teammates_alive":3,"zone_pressure":0,"cover":1,"squad_distance":0}

def now(): return datetime.now(timezone.utc).isoformat()
def clamp(x,lo=0.0,hi=1.0): return max(lo,min(hi,float(x)))
def vector(state):
    vals={**DEFAULTS,**state}; out=[]
    for k in FEATURES:
        x=float(vals[k])
        if k in ("health","shield") and x>1: x/=100
        elif k=="ammo" and x>1: x=min(1,x/300)
        elif k=="enemies" and x>1: x=min(1,x/4)
        elif k=="teammates_alive" and x>1: x=min(1,x/3)
        elif k=="squad_distance" and x>1: x=min(1,x/100)
        out.append(clamp(x))
    return out

def derived_reward(s, ns, events=None):
    """Conservative shaped reward; movement itself is not rewarded."""
    a,b=vector(s),vector(ns)
    # positive health/shield changes help; losses hurt more than gains help
    dh=b[0]-a[0]; ds=b[1]-a[1]
    r= (2.2*dh if dh>=0 else 3.2*dh) + (1.2*ds if ds>=0 else 1.8*ds)
    r += 1.1*(b[6]-a[6])                 # improved cover
    r += 0.9*(a[5]-b[5])                 # lower zone pressure
    r += 0.7*(a[7]-b[7])                 # closer to squad
    r += 0.5*(b[4]-a[4])                 # teammate survival/revival signal
    ev=events or {}
    r += 0.8*clamp(ev.get("damage_dealt",0)/100,0,2)
    r += 1.5*float(bool(ev.get("knock",False)))
    r += 1.0*float(bool(ev.get("revive",False)))
    r -= 2.0*float(bool(ev.get("death",False)))
    r += 3.0*float(bool(ev.get("win",False)))
    # A health loss during movement can cancel the positional gain; no raw movement bonus.
    return round(max(-4.0,min(4.0,r)),4)

def append_jsonl(path,row):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("a",encoding="utf-8") as f:f.write(json.dumps(row,ensure_ascii=False)+"\n")
def load_transitions():
    out=[]
    if not TRANSITIONS.exists():return out
    for n,line in enumerate(TRANSITIONS.read_text(encoding="utf-8").splitlines(),1):
        if not line.strip():continue
        try:
            d=json.loads(line)
            if d["action"] not in ACTIONS: raise ValueError("action invalide")
            out.append({"s":vector(d["state"]),"a":ACTIONS.index(d["action"]),
                        "r":float(d["reward"]),"ns":vector(d["next_state"]),
                        "done":bool(d.get("done",False)),"source":d.get("source","unknown")})
        except Exception as e: raise ValueError(f"Transition invalide ligne {n}: {e}") from e
    return out

class DQN:
    """Tiny NumPy MLP Q-network with replay training and a target network."""
    def __init__(self,seed=17):
        import numpy as np
        self.np=np; rng=np.random.default_rng(seed)
        self.w1=rng.normal(0,.18,(8,32)); self.b1=np.zeros(32)
        self.w2=rng.normal(0,.12,(32,5)); self.b2=np.zeros(5)
        self.tw1=self.w1.copy();self.tb1=self.b1.copy();self.tw2=self.w2.copy();self.tb2=self.b2.copy()
    def forward(self,x,target=False):
        np=self.np
        w1,b1,w2,b2=(self.tw1,self.tb1,self.tw2,self.tb2) if target else (self.w1,self.b1,self.w2,self.b2)
        h=np.tanh(x@w1+b1);q=h@w2+b2
        return h,q
    def qvalues(self,x):
        np=self.np; _,q=self.forward(np.asarray(x,dtype=float).reshape(1,8));return q[0]
    def act(self,state):
        q=self.qvalues(vector(state));i=int(self.np.argmax(q))
        return ACTIONS[i], [round(float(v),4) for v in q]
    def train(self,rows,epochs=60,gamma=.92,lr=.002,seed=17):
        np=self.np;rng=random.Random(seed); losses=[]
        if len(rows)<5: raise ValueError("Minimum 5 transitions pour un prototype; davantage et plusieurs épisodes sont fortement recommandés.")
        # Holdout partition is by shuffled transitions; episode-level splits are preferable for real evaluation.
        data=list(rows);rng.shuffle(data);n=max(1,round(len(data)*.2));test=data[:n];train=data[n:]
        for epoch in range(max(1,min(epochs,1000))):
            rng.shuffle(train); batchloss=[]
            for item in train:
                x=np.asarray(item["s"],float); ns=np.asarray(item["ns"],float)
                h,q=self.forward(x.reshape(1,8)); q=q[0]
                _,nq_online=self.forward(ns.reshape(1,8)); _,nq_target=self.forward(ns.reshape(1,8),target=True)
                next_a=int(np.argmax(nq_online[0]))
                target=item["r"]+(0 if item["done"] else gamma*float(nq_target[0,next_a]))
                err=float(q[item["a"]]-target); batchloss.append(err*err)
                # semi-gradient update for selected action, MSE loss
                dq=np.zeros(5);dq[item["a"]]=2*max(-5,min(5,err))
                oldw2=self.w2.copy()
                self.w2-=lr*(h.T@dq.reshape(1,5));self.b2-=lr*dq
                dh=(dq@oldw2.T)*(1-h[0]**2)
                self.w1-=lr*np.outer(x,dh);self.b1-=lr*dh
            # periodically synchronize target network
            if epoch%5==0:
                self.tw1=self.w1.copy();self.tb1=self.b1.copy();self.tw2=self.w2.copy();self.tb2=self.b2.copy()
            losses.append(sum(batchloss)/max(1,len(batchloss)))
        # Report holdout TD error (not a claim of gameplay performance)
        errors=[]
        for it in test:
            _,q=self.forward(np.asarray(it["s"]).reshape(1,8))
            _,nqo=self.forward(np.asarray(it["ns"]).reshape(1,8))
            _,nqt=self.forward(np.asarray(it["ns"]).reshape(1,8),target=True)
            na=int(np.argmax(nqo[0])); tgt=it["r"]+(0 if it["done"] else gamma*float(nqt[0,na]))
            errors.append((float(q[0,it["a"]])-tgt)**2)
        return {"transitions":len(rows),"train_transitions":len(train),"holdout_transitions":len(test),
                "final_train_td_mse":round(losses[-1],6),"holdout_td_mse":round(sum(errors)/len(errors),6),
                "caveat":"Le TD-MSE mesure l'ajustement aux transitions, pas la qualité en partie. Utiliser plusieurs épisodes et une évaluation indépendante."}
    def save(self):
        DATA.mkdir(parents=True,exist_ok=True)
        payload={"format":"joyce-dqn-v1","features":list(FEATURES),"actions":list(ACTIONS),
                 "w1":self.w1.tolist(),"b1":self.b1.tolist(),"w2":self.w2.tolist(),"b2":self.b2.tolist(),
                 "target":{"w1":self.tw1.tolist(),"b1":self.tb1.tolist(),"w2":self.tw2.tolist(),"b2":self.tb2.tolist()}}
        tmp=MODEL.with_suffix(".tmp");tmp.write_text(json.dumps(payload),encoding="utf-8");tmp.replace(MODEL)
    @classmethod
    def load(cls):
        import numpy as np
        d=json.loads(MODEL.read_text(encoding="utf-8"))
        if d.get("format")!="joyce-dqn-v1" or d.get("actions")!=list(ACTIONS):raise ValueError("Format modèle invalide")
        m=cls()
        for k in ("w1","b1","w2","b2"):setattr(m,k,np.asarray(d[k],float))
        t=d["target"]
        for k in ("w1","b1","w2","b2"):setattr(m,"t"+k,np.asarray(t[k],float))
        return m

def rag(query,limit=3):
    """Small local lexical retriever. Returns source snippets; no fabricated web claims."""
    docs=[]
    for p in sorted((ROOT/"knowledge").glob("*.md")):
        docs.append((str(p.relative_to(ROOT)),p.read_text(encoding="utf-8")))
    if TRANSITIONS.exists():
        for i,line in enumerate(TRANSITIONS.read_text(encoding="utf-8").splitlines()):
            try:
                d=json.loads(line); docs.append((f"episode:{i+1}",json.dumps({"action":d["action"],"reward":d["reward"],"events":d.get("events",{}),"note":d.get("note","")},ensure_ascii=False)))
            except Exception: pass
    terms=set(re.findall(r"\w+",query.lower()))
    scored=[]
    for source,body in docs:
        tokens=re.findall(r"\w+",body.lower()); vocab=set(tokens)
        score=sum(1+math.log1p(tokens.count(t)) for t in terms & vocab)/(1+math.log1p(len(tokens)))
        if score>0:scored.append((score,source,body))
    scored.sort(reverse=True)
    return [{"score":round(s,4),"source":src,"snippet":body[:900]} for s,src,body in scored[:max(1,min(10,limit))]]

def main():
    p=argparse.ArgumentParser(description="Joyce V8: RAG local + prototype Deep RL hors ligne")
    sp=p.add_subparsers(dest="cmd",required=True)
    a=sp.add_parser("ingest",help="ingérer une transition structurée et calculer sa récompense")
    a.add_argument("--json",required=True,help='JSON avec state, action, next_state et éventuellement events, reward, done, note')
    t=sp.add_parser("train",help="entraîner le DQN sur les transitions enregistrées")
    t.add_argument("--epochs",type=int,default=60)
    ac=sp.add_parser("act",help="estimer les valeurs Q d'un état donné")
    ac.add_argument("--state",required=True,help="objet JSON de l'état observé")
    r=sp.add_parser("rag",help="retrouver des documents locaux et épisodes similaires")
    r.add_argument("query");r.add_argument("--limit",type=int,default=3)
    sp.add_parser("stats",help="statistiques des transitions")
    args=p.parse_args()
    try:
        if args.cmd=="ingest":
            d=json.loads(args.json)
            if not isinstance(d.get("state"),dict) or not isinstance(d.get("next_state"),dict):raise ValueError("state et next_state doivent être des objets JSON")
            if d.get("action") not in ACTIONS:raise ValueError("Action invalide : "+", ".join(ACTIONS))
            ev=d.get("events",{})
            reward=float(d["reward"]) if "reward" in d else derived_reward(d["state"],d["next_state"],ev)
            reward_reason="explicit_feedback" if "reward" in d else "derived_from_deltas"
            # User's conservative preference: if a reposition/regroup action incurs health or shield loss,
            # don't label that move as positive from positional gains alone; score it at most neutral.
            if "reward" not in d and d["action"] in ("reposition","regroup"):
                before,after=vector(d["state"]),vector(d["next_state"])
                if after[0] < before[0] or after[1] < before[1]:
                    reward=min(0.0,reward)
                    reward_reason="derived_deltas_damage_during_movement_capped_at_zero"
            row={"timestamp":now(),"state":d["state"],"action":d["action"],"next_state":d["next_state"],
                 "events":ev,"reward":round(max(-4,min(4,reward)),4),"reward_source":reward_reason,
                 "done":bool(d.get("done",False)),"note":str(d.get("note",""))[:1000],"source":"local_structured_observation"}
            append_jsonl(TRANSITIONS,row);print(json.dumps(row,ensure_ascii=False,indent=2));return 0
        if args.cmd=="rag":
            print(json.dumps(rag(args.query,args.limit),ensure_ascii=False,indent=2));return 0
        if args.cmd=="stats":
            rows=load_transitions();print(json.dumps({"transition_count":len(rows),"actions":{a:sum(x["a"]==i for x in rows) for i,a in enumerate(ACTIONS)},"model_exists":MODEL.exists()},ensure_ascii=False,indent=2));return 0
        if args.cmd=="train":
            rows=load_transitions();m=DQN();report=m.train(rows,args.epochs);m.save();print(json.dumps({**report,"model":str(MODEL)},ensure_ascii=False,indent=2));return 0
        if args.cmd=="act":
            m=DQN.load() if MODEL.exists() else DQN()
            action,qs=m.act(json.loads(args.state))
            print(json.dumps({"action_suggestion":action,"q_values":dict(zip(ACTIONS,qs)),"model_loaded":MODEL.exists(),"warning":"Suggestion expérimentale. État fourni localement; aucune commande envoyée au jeu."},ensure_ascii=False,indent=2));return 0
    except (OSError,ValueError,KeyError,TypeError,ImportError,json.JSONDecodeError) as e:
        print(f"Erreur Joyce V8 : {e}",file=sys.stderr);return 2
    return 1
if __name__=="__main__":raise SystemExit(main())
