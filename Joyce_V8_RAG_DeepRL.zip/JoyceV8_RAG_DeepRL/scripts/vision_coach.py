#!/usr/bin/env python3
"""Interprète prudemment un rapport Joyce Vision via Ollama local."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_API = os.environ.get("JOYCE_API_URL", "http://localhost:11434/api/chat")
DEFAULT_MODEL = os.environ.get("JOYCE_MODEL", "qwen2.5:3b")
DEFAULT_OUT = Path(os.environ.get("JOYCE_VISION_ANALYSIS_FILE", ROOT / "data/joyce_vision_analysis.json"))

SYSTEM_PROMPT = """Tu es Joyce, assistant d'analyse prudente de métriques visuelles de jeu.
Tu ne vois PAS les pixels : tu reçois uniquement des métriques calculées par OpenCV.
Ne déduis jamais la présence d'un ennemi, une élimination, un tir ou un événement Apex depuis ces seules métriques.
Sépare clairement les faits fournis et les hypothèses. Si les données sont insuffisantes, dis-le.
Réponds uniquement avec un objet JSON contenant exactement ces clés :
summary (chaîne), observations (tableau de chaînes), hypotheses (tableau de chaînes),
confidence (nombre entre 0 et 1), recommendations (tableau de chaînes), limitations (tableau de chaînes).
Les observations doivent se limiter aux chiffres présents dans le rapport. Les recommandations doivent rester générales et non affirmatives."""


def build_context(report: dict) -> dict:
    summary = report.get("summary") if isinstance(report.get("summary"), dict) else {}
    return {
        "media_type": report.get("media_type", "inconnu"),
        "frames_analyzed": report.get("frames_analyzed", 0),
        "video_duration_seconds": report.get("video_duration_seconds"),
        "sample_interval_seconds_requested": report.get("sample_interval_seconds_requested"),
        "summary": {k: summary.get(k) for k in (
            "mean_brightness_0_255", "mean_edge_density_percent",
            "mean_visual_change_score_0_255", "significant_visual_changes")},
        "limitations": report.get("limitations", []),
    }


def validate_result(value: object) -> dict:
    if not isinstance(value, dict):
        raise ValueError("La réponse du modèle n'est pas un objet JSON.")
    required = {"summary": str, "observations": list, "hypotheses": list,
                "confidence": (int, float), "recommendations": list, "limitations": list}
    for key, typ in required.items():
        if key not in value or not isinstance(value[key], typ):
            raise ValueError(f"Champ JSON manquant ou invalide : {key}")
    if isinstance(value["confidence"], bool) or not 0 <= float(value["confidence"]) <= 1:
        raise ValueError("confidence doit être un nombre compris entre 0 et 1.")
    for key in ("observations", "hypotheses", "recommendations", "limitations"):
        if not all(isinstance(item, str) for item in value[key]):
            raise ValueError(f"Tous les éléments de {key} doivent être des chaînes.")
    return {"summary": value["summary"], "observations": value["observations"],
            "hypotheses": value["hypotheses"], "confidence": float(value["confidence"]),
            "recommendations": value["recommendations"], "limitations": value["limitations"]}


def ask_ollama(context: dict, api_url: str = DEFAULT_API, model: str = DEFAULT_MODEL,
               timeout: float = 90.0) -> dict:
    payload = {"model": model, "stream": False, "format": "json", "messages": [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": "Analyse ce rapport de métriques, sans inventer d'événements :\n" + json.dumps(context, ensure_ascii=False)}
    ], "options": {"temperature": 0.2}}
    request = urllib.request.Request(api_url, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Ollama inaccessible à {api_url} : {exc}") from exc
    except (TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Réponse Ollama illisible ou délai dépassé : {exc}") from exc
    if not isinstance(body, dict) or not isinstance(body.get("message"), dict):
        raise RuntimeError("Réponse Ollama inattendue : champ message absent.")
    content = body["message"].get("content")
    if not isinstance(content, str):
        raise RuntimeError("Réponse Ollama inattendue : contenu absent.")
    try:
        return validate_result(json.loads(content))
    except (json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"Le modèle n'a pas produit le JSON attendu : {exc}") from exc


def run(report_path: Path, out_path: Path, api_url: str, model: str, timeout: float) -> dict:
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise RuntimeError(f"Rapport introuvable : {report_path}") from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Rapport JSON illisible : {exc}") from exc
    if not isinstance(report, dict) or not isinstance(report.get("summary"), dict):
        raise RuntimeError("Le fichier ne ressemble pas à un rapport Joyce Vision valide.")
    context = build_context(report)
    result = ask_ollama(context, api_url=api_url, model=model, timeout=timeout)
    output = {"schema_version": 1, "created_at": datetime.now(timezone.utc).isoformat(),
              "model": model, "source_report": str(report_path.resolve()), "context": context, **result}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return output


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Interprète un rapport Joyce Vision avec Ollama local.")
    p.add_argument("report", type=Path, help="Rapport JSON créé par scripts/vision.py")
    p.add_argument("--out", type=Path, default=DEFAULT_OUT, help="Fichier JSON d'analyse")
    p.add_argument("--api-url", default=DEFAULT_API, help="URL Ollama /api/chat")
    p.add_argument("--model", default=DEFAULT_MODEL, help="Nom du modèle Ollama")
    p.add_argument("--timeout", type=float, default=90.0, help="Délai maximal en secondes")
    args = p.parse_args(argv)
    if args.timeout <= 0:
        p.error("--timeout doit être strictement positif")
    try:
        result = run(args.report.expanduser().resolve(), args.out.expanduser().resolve(), args.api_url, args.model, args.timeout)
    except RuntimeError as exc:
        print(f"Erreur Joyce Coach : {exc}", file=sys.stderr)
        return 1
    print("Analyse Ollama terminée :")
    print(result["summary"])
    print(f"Confiance déclarée par le modèle : {result['confidence']:.0%}")
    print(f"Rapport : {args.out.expanduser().resolve()}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
