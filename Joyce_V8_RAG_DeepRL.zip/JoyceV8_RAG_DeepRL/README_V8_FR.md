# Joyce V8 — RAG local + Deep RL expérimental

Cette version ajoute deux composants séparés :
1. **RAG lexical local** : recherche de documents de connaissance et d'épisodes stockés localement, avec provenance.
2. **Prototype Double-DQN hors ligne** : réseau Q à couches denses, mémoire de transitions dans un fichier JSONL, calcul automatique d'une récompense à partir des différences entre état initial et état suivant, et entraînement/test hors ligne.

## Important
- Ce n'est pas un NN parfait. La qualité dépend de la qualité des observations, des récompenses, des transitions et de la diversité des épisodes.
- Le mouvement seul n'est pas récompensé. Le moteur considère plutôt les changements de couvert, de pression de zone, de distance à l'escouade, de santé et de bouclier. Prendre des dégâts en se repositionnant peut donc réduire ou annuler le bénéfice.
- La récompense automatique est un signal heuristique, pas une preuve causale. Les résultats retardés et les actions intervenues entre deux observations demandent une attribution temporelle prudente.
- Les données doivent être fournies sous forme JSON structurée par l'utilisateur ou par une intégration autorisée. Aucun accès mémoire, contrôle, chat, connexion ou action automatique dans Apex n'est implémenté.
- Le DQN hors ligne peut surestimer des actions peu présentes dans les données. Ne pas considérer la MSE TD comme une mesure de performance en jeu. Évaluer sur plusieurs épisodes tenus à l'écart.

## Dépendance
`python3-numpy` (Debian : `sudo apt install python3-numpy`). Aucun framework deep-learning lourd n'est requis.

## Exemples

Enregistrer une transition; la récompense est calculée automatiquement :
```bash
python3 scripts/joyce_brain.py ingest --json '{"state":{"health":100,"shield":100,"cover":0.2,"zone_pressure":0.7,"squad_distance":50},"action":"reposition","next_state":{"health":80,"shield":100,"cover":0.8,"zone_pressure":0.3,"squad_distance":30},"events":{"damage_dealt":20}}'
```
Le fait de bouger n'ajoute pas de récompense tout seul. Le bénéfice positionnel est compensé par la perte de santé.

Recherche RAG locale :
```bash
python3 scripts/joyce_brain.py rag "prendre des dégâts en se repositionnant"
```
Statistiques :
```bash
python3 scripts/joyce_brain.py stats
```
Entraînement sur au moins cinq transitions (plusieurs centaines ou milliers de transitions représentatives sont préférables) :
```bash
python3 scripts/joyce_brain.py train --epochs 60
```
Prédire des valeurs Q :
```bash
python3 scripts/joyce_brain.py act --state '{"health":40,"shield":20,"ammo":60,"enemies":2,"teammates_alive":2,"zone_pressure":0.6,"cover":0.3,"squad_distance":40}'
```
Les actions possibles sont `take_cover`, `heal_or_recharge`, `regroup`, `reposition`, `engage`.

## Tests
```bash
python3 tests/test_joyce_brain.py
```
