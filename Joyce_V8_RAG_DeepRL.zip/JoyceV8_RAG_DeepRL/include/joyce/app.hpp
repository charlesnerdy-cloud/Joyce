#pragma once

#include "joyce/apex_adapter.hpp"
#include "joyce/config.hpp"
#include "joyce/memory.hpp"
#include "joyce/ollama_client.hpp"

#include <nlohmann/json.hpp>
#include <string>

namespace joyce {

class App {
public:
    explicit App(Config config);
    int run();

private:
    Config config_;
    Memory memory_;
    OllamaClient ollama_;
    ApexAdapter apex_;
    nlohmann::json journal_;
    std::string journalFile_;

    void printHelp() const;
    void printStatus() const;
    void handleInput(const std::string& input, bool& keepRunning);
    bool loadJournal();
    bool saveJournal() const;
    void printStats() const;
    void coach(const std::string& situation);
    void reviewLastSession();
    void printInsights();
    void importJson(const std::string& path);
    void exportJson(const std::string& path) const;
    std::string progressionContext(std::size_t limit = 10) const;
};

} // namespace joyce
