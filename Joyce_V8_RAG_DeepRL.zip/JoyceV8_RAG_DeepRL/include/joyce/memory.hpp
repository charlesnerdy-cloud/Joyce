#pragma once

#include <nlohmann/json.hpp>
#include <string>

namespace joyce {

class Memory {
public:
    explicit Memory(std::string path, std::size_t maxMessages = 20);

    bool load();
    bool save() const;
    void resetHistory();
    void addExchange(const std::string& user, const std::string& assistant);

    const nlohmann::json& profile() const;
    const nlohmann::json& messages() const;
    nlohmann::json& profile();

private:
    std::string path_;
    std::size_t maxMessages_;
    nlohmann::json data_;
    void normalize();
    void trimHistory();
};

} // namespace joyce
