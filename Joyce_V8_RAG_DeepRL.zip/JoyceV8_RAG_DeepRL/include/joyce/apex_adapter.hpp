#pragma once

#include <string>

namespace joyce {

struct Observation {
    bool available = false;
    std::string source = "aucune";
    std::string summary = "Aucune source d'observation autorisée n'est connectée.";
};

// Interface volontairement passive : pas de lecture de mémoire du jeu,
// d'injection d'entrées, ni de contournement de l'anti-triche.
class ApexAdapter {
public:
    Observation observe() const;
};

} // namespace joyce
