#pragma once

#include <cstdlib>
#include <string>

namespace joyce {

inline std::string envOr(const char* name, const std::string& fallback) {
    const char* value = std::getenv(name);
    return value && *value ? std::string(value) : fallback;
}

struct Config {
    std::string model = envOr("JOYCE_MODEL", "qwen2.5:3b");
    std::string apiUrl = envOr("JOYCE_API_URL", "http://localhost:11434/api/chat");
    std::string memoryFile = envOr("JOYCE_MEMORY_FILE", "data/joyce_memory.json");
    std::size_t maxMessages = 20;
    long connectTimeoutSeconds = 5;
    long requestTimeoutSeconds = 180;
};

} // namespace joyce
