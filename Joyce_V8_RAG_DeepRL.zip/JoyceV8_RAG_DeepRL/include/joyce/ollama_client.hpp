#pragma once

#include "joyce/config.hpp"
#include "joyce/memory.hpp"
#include <string>

namespace joyce {

class OllamaClient {
public:
    explicit OllamaClient(Config config);
    bool ask(const std::string& userText, const Memory& memory, std::string& answer,
             std::string& error) const;
    const Config& config() const;

private:
    Config config_;
    std::string systemPrompt(const Memory& memory) const;
};

} // namespace joyce
