# Joyce V7 — Learning Companion

Joyce V7 ajoute une boucle d'apprentissage **contrôlée et mesurable** au compagnon local V6 :
- mémoire locale et profil persistants déjà fournis par V6 ;
- vision locale via les scripts V6/Ollama ;
- exemples de décision explicitement annotés par un humain ;
- entraînement sur exemples annotés uniquement (pas de modification silencieuse des poids) ;
- séparation entraînement/test et rapport de précision ;
- pas de connexion, de contrôle, de chat automatisé ou de pilotage d'Apex.

## Dépendances

Python 3.11+ (testé avec Python 3.13), OpenCV/Python OpenCV et les dépendances système nécessaires à la compilation native V6. Ollama n'est requis que pour les fonctions vision/raisonnement qui l'utilisent.

## Démarrer le compagnon local

```bash
chmod +x scripts/*.sh scripts/*.py
./scripts/run_v7.sh
```

Le compagnon local demande un PIN de session dans stdout. Dans le même terminal, saisir `/pin <PIN>`. L'état `PRÊT` concerne uniquement Joyce, pas le lobby Apex.

Commandes du compagnon : `/help`, `/status`, `/remember <clé> <valeur>`, `/goal <objectif>`, `/coach <JSON état>`, `/feedback ...`, `/observe <chemin image>`, `/quit`.

## Ajouter des exemples validés par toi

Chaque exemple doit être annoté manuellement. Les valeurs d'état sont fournies par l'utilisateur ; Joyce ne lit pas la mémoire du jeu.

```bash
python3 scripts/joyce_learning.py add \
  --state '{"health":25,"shield":10,"ammo":80,"enemies":2,"teammates_alive":2,"zone_pressure":0.7,"cover":0.8,"squad_distance":0.2}' \
  --action heal_or_recharge \
  --note "Exemple annoté manuellement"
python3 scripts/joyce_learning.py stats
```

Actions possibles : `take_cover`, `heal_or_recharge`, `regroup`, `reposition`, `engage`.

## Entraîner et évaluer

Il faut au minimum 5 exemples, mais davantage et des situations variées sont fortement recommandés. Le rapport garde un jeu de test à l'écart de l'entraînement.

```bash
python3 scripts/joyce_learning.py train --epochs 250
python3 scripts/joyce_learning.py evaluate
```

Attention : cinq exemples ne suffisent pas à construire une politique fiable. L'exactitude mesurée sur un jeu réduit n'est pas une preuve de compétence en jeu. Compare les métriques, conserve les sauvegardes du modèle et ajoute des annotations représentatives avant d'utiliser les recommandations.

## Tests

```bash
python3 tests/test_companion.py
python3 tests/test_teammate_nn.py
python3 tests/test_joyce_learning.py
```

## Données locales

- `data/joyce_profile.json` : préférences et objectifs.
- `data/joyce_companion_events.jsonl` : événements de session.
- `data/joyce_reviewed_examples.jsonl` : exemples annotés.
- `data/joyce_policy_nn.json` : modèle local.
- `data/joyce_teammate_history.jsonl` : recommandations.

Ces fichiers peuvent contenir des données personnelles : garde-les localement et sauvegarde-les avant mise à jour.

## Apprentissage par feedback automatique (V7.1)

Joyce peut désormais transformer un événement que tu lui signales en récompense, enregistrer l'état + l'action + le résultat, puis mettre à jour un petit MLP de prédiction de récompense après chaque feedback. Le modèle et l'historique sont conservés localement.

```bash
# Exemples de feedback explicite (l'état est un JSON fourni par l'observateur)
python3 scripts/joyce_rl.py feedback \
  --state '{"health":55,"shield":20,"ammo":80,"enemies":1,"teammates_alive":2,"zone_pressure":0.4,"cover":0.3,"squad_distance":0.2}' \
  --action reposition --event damage

python3 scripts/joyce_rl.py feedback \
  --state '{"health":55,"shield":20,"ammo":80,"enemies":1,"teammates_alive":2,"zone_pressure":0.4,"cover":0.7,"squad_distance":0.2}' \
  --action reposition --event move_safe

python3 scripts/joyce_rl.py feedback \
  --state '{"health":55,"shield":20,"ammo":80,"enemies":1,"teammates_alive":2,"zone_pressure":0.4,"cover":0.3,"squad_distance":0.2}' \
  --action reposition --event move_damage

# Estimer le retour des actions pour un état donné
python3 scripts/joyce_rl.py predict --state '{"health":55,"shield":20,"ammo":80,"enemies":1,"teammates_alive":2,"zone_pressure":0.4,"cover":0.3,"squad_distance":0.2}'
python3 scripts/joyce_rl.py stats
python3 tests/test_joyce_rl.py
```

Récompenses par défaut : `damage=-1`, `move_safe=+1`, `move_damage=0`, `survive=+0.5`, `downed=-1`, `objective=+0.7`, `manual_neutral=0`. Ce sont des heuristiques configurables, pas des vérités universelles : un déplacement suivi de dégâts peut être correct si le gain tactique est supérieur. Les événements sont enregistrés automatiquement **après que l'observateur les a fournis** ; cette version ne lit pas automatiquement l'état interne d'Apex. Ne pas présenter ces retours comme une mesure complète de la qualité tactique.
