# Architecture Joyce : RAG + apprentissage par renforcement

RAG et apprentissage sont deux composants différents.
- RAG récupère des documents ou épisodes similaires et doit conserver leur provenance.
- Le réseau Q apprend une estimation de récompense cumulée pour des actions discrètes à partir de transitions (état, action, récompense, état suivant, fin d'épisode).
- Les retours explicites peuvent compléter les signaux observés.
- En apprentissage hors ligne, le modèle peut surévaluer des actions peu représentées. Limiter l'usage aux actions couvertes par les données et valider les politiques sur des données indépendantes.
