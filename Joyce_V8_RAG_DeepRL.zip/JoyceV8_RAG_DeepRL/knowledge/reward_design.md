# Récompenses et attribution causale

Une récompense doit mesurer le résultat utile, pas l'activité brute. Le déplacement seul ne reçoit pas de bonus : on crédite un déplacement si les observations montrent une amélioration de couvert, de zone ou de proximité de l'escouade, et on soustrait les pertes de santé/bouclier. Les résultats différés sont attribués à une transition et restent incertains si plusieurs actions ont eu lieu entre deux observations.

Ne pas utiliser une seule partie comme preuve causale. Comparer des situations similaires, utiliser plusieurs épisodes, conserver un jeu de test séparé et surveiller les effets indésirables.
