#include "joyce/apex_adapter.hpp"

namespace joyce {

Observation ApexAdapter::observe() const {
    // Point d'extension pour une source documentée et autorisée, par exemple
    // des statistiques exportées par l'utilisateur ou un mode d'entraînement.
    return {};
}

} // namespace joyce
