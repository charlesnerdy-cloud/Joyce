#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
using json = nlohmann::json;

namespace {
struct FrameMetric {
    double time_seconds{};
    double mean_brightness{};
    double edge_density{};
    double motion_score{};
    bool visual_change{};
};

cv::Mat toGray(const cv::Mat& frame) {
    if (frame.empty()) throw std::runtime_error("Image vide ou illisible.");
    cv::Mat gray;
    if (frame.channels() == 1) gray = frame.clone();
    else if (frame.channels() == 4) cv::cvtColor(frame, gray, cv::COLOR_BGRA2GRAY);
    else cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    return gray;
}

FrameMetric measure(const cv::Mat& frame, const cv::Mat& previous, double timeSeconds) {
    const cv::Mat gray = toGray(frame);
    cv::Scalar meanValue = cv::mean(gray);
    cv::Mat edges;
    cv::Canny(gray, edges, 80, 160);
    const double edgeDensity = 100.0 * static_cast<double>(cv::countNonZero(edges)) /
                               static_cast<double>(edges.total());
    double motion = 0.0;
    if (!previous.empty()) {
        cv::Mat priorResized;
        if (previous.size() == gray.size()) priorResized = previous;
        else cv::resize(previous, priorResized, gray.size());
        cv::Mat delta;
        cv::absdiff(gray, priorResized, delta);
        motion = cv::mean(delta)[0];
    }
    return {timeSeconds, meanValue[0], edgeDensity, motion, motion >= 18.0};
}

json metricJson(const FrameMetric& m) {
    return {{"time_seconds", m.time_seconds}, {"mean_brightness_0_255", m.mean_brightness},
            {"edge_density_percent", m.edge_density}, {"visual_change_score_0_255", m.motion_score},
            {"significant_visual_change", m.visual_change}};
}

int runSelfTest() {
    cv::Mat dark(120, 160, CV_8UC3, cv::Scalar(0, 0, 0));
    cv::Mat bright(120, 160, CV_8UC3, cv::Scalar(255, 255, 255));
    const auto a = measure(dark, {}, 0.0);
    const auto b = measure(bright, toGray(dark), 1.0);
    if (std::abs(a.mean_brightness) > 0.01 || b.mean_brightness < 254.0 || b.motion_score < 250.0 || !b.visual_change) {
        std::cerr << "ÉCHEC: métriques visuelles inattendues.\n";
        return 1;
    }
    std::cout << "OK: auto-test vision (luminosité, contours, changement visuel).\n";
    return 0;
}

void usage(const char* exe) {
    std::cerr << "Usage: " << exe << " <image-ou-video> [--out rapport.json] [--sample-seconds N]\n"
              << "       " << exe << " --self-test\n";
}
}

int main(int argc, char** argv) {
    try {
        if (argc == 2 && std::string(argv[1]) == "--self-test") return runSelfTest();
        if (argc < 2) { usage(argv[0]); return 2; }
        fs::path input = argv[1];
        fs::path output = "data/joyce_vision_report.json";
        double sampleSeconds = 1.0;
        for (int i = 2; i < argc; ++i) {
            const std::string arg = argv[i];
            if (arg == "--out" && i + 1 < argc) output = argv[++i];
            else if (arg == "--sample-seconds" && i + 1 < argc) sampleSeconds = std::stod(argv[++i]);
            else { usage(argv[0]); return 2; }
        }
        if (sampleSeconds <= 0.0 || sampleSeconds > 3600.0) throw std::runtime_error("--sample-seconds doit être entre 0 et 3600.");
        if (!fs::exists(input) || !fs::is_regular_file(input)) throw std::runtime_error("Fichier introuvable : " + input.string());

        std::vector<FrameMetric> metrics;
        cv::Mat image = cv::imread(input.string(), cv::IMREAD_UNCHANGED);
        std::string mediaType = "image";
        double fps = 0.0;
        double duration = 0.0;
        if (!image.empty()) {
            metrics.push_back(measure(image, {}, 0.0));
        } else {
            cv::VideoCapture video(input.string());
            if (!video.isOpened()) throw std::runtime_error("Impossible de lire ce fichier comme image ou vidéo prise en charge.");
            mediaType = "video";
            fps = video.get(cv::CAP_PROP_FPS);
            const double frameCount = video.get(cv::CAP_PROP_FRAME_COUNT);
            if (fps > 0.0 && frameCount > 0.0) duration = frameCount / fps;
            const double interval = std::max(1.0, (fps > 0.0 ? fps : 1.0) * sampleSeconds);
            cv::Mat frame, previousGray;
            long long frameIndex = 0;
            while (video.read(frame)) {
                if (frameIndex % static_cast<long long>(interval) == 0) {
                    const double t = fps > 0.0 ? static_cast<double>(frameIndex) / fps : static_cast<double>(frameIndex);
                    auto m = measure(frame, previousGray, t);
                    metrics.push_back(m);
                    previousGray = toGray(frame);
                }
                ++frameIndex;
            }
            if (metrics.empty()) throw std::runtime_error("Aucune image vidéo lisible.");
        }

        double brightnessSum = 0.0, edgeSum = 0.0, motionSum = 0.0;
        std::size_t changes = 0;
        json frames = json::array();
        for (const auto& m : metrics) {
            brightnessSum += m.mean_brightness;
            edgeSum += m.edge_density;
            motionSum += m.motion_score;
            if (m.visual_change) ++changes;
            frames.push_back(metricJson(m));
        }
        const double count = static_cast<double>(metrics.size());
        json report = {
            {"schema_version", 1}, {"tool", "Joyce Vision V5.1"}, {"media_path", fs::absolute(input).string()},
            {"media_type", mediaType}, {"video_fps", fps}, {"video_duration_seconds", duration},
            {"sample_interval_seconds_requested", sampleSeconds}, {"frames_analyzed", metrics.size()},
            {"summary", {{"mean_brightness_0_255", brightnessSum / count},
                          {"mean_edge_density_percent", edgeSum / count},
                          {"mean_visual_change_score_0_255", motionSum / count},
                          {"significant_visual_changes", changes}}},
            {"frames", frames},
            {"limitations", {"These are low-level visual metrics, not Apex object recognition.",
                             "No game memory, network traffic, keyboard, mouse, or controller input is accessed.",
                             "A visual change is not proof of an enemy, hit, kill, or tactical event."}}
        };
        if (!output.parent_path().empty()) fs::create_directories(output.parent_path());
        std::ofstream out(output);
        if (!out) throw std::runtime_error("Impossible d'écrire le rapport : " + output.string());
        out << std::setw(2) << report << '\n';
        std::cout << "Analyse terminée.\nType : " << mediaType << "\nImages analysées : " << metrics.size()
                  << "\nChangements visuels significatifs : " << changes << "\nRapport : " << output << '\n'
                  << "Note : il s'agit de métriques visuelles de base, pas d'une reconnaissance des objets Apex.\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Erreur Joyce Vision : " << e.what() << '\n';
        return 1;
    }
}
