#include "joyce/memory.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <utility>

namespace joyce {

Memory::Memory(std::string path, std::size_t maxMessages)
    : path_(std::move(path)), maxMessages_(maxMessages), data_(nlohmann::json::object()) {
    normalize();
}

void Memory::normalize() {
    if (!data_.is_object()) data_ = nlohmann::json::object();

    if (!data_.contains("profile") || !data_["profile"].is_object()) {
        data_["profile"] = {
            {"name", "Joyce"},
            {"language", "français"},
            {"style", "naturel, clair et concis"},
            {"project", "assistant IA local multi-jeux, avec un module Apex Legends"}
        };
    }
    if (!data_.contains("messages") || !data_["messages"].is_array()) {
        data_["messages"] = nlohmann::json::array();
    }
    trimHistory();
}

void Memory::trimHistory() {
    auto& messages = data_["messages"];
    while (messages.size() > maxMessages_) messages.erase(messages.begin());
}

bool Memory::load() {
    std::ifstream file(path_);
    if (!file) {
        normalize();
        return save();
    }

    try {
        file >> data_;
        normalize();
        return save();
    } catch (const std::exception& error) {
        std::cerr << "Mémoire illisible (" << error.what()
                  << "). Une mémoire propre va être créée.\n";
        data_ = nlohmann::json::object();
        normalize();
        return save();
    }
}

bool Memory::save() const {
    namespace fs = std::filesystem;
    try {
        const fs::path destination(path_);
        if (!destination.parent_path().empty()) {
            fs::create_directories(destination.parent_path());
        }
        const fs::path temporary = destination.string() + ".tmp";
        {
            std::ofstream file(temporary, std::ios::binary | std::ios::trunc);
            if (!file) {
                std::cerr << "Impossible d'ouvrir le fichier temporaire de mémoire : "
                          << temporary.string() << '\n';
                return false;
            }
            file << data_.dump(2) << '\n';
            if (!file) {
                std::cerr << "Erreur pendant l'écriture de la mémoire.\n";
                return false;
            }
        }
        std::error_code ec;
        fs::rename(temporary, destination, ec);
        if (ec) {
            // Some filesystems do not replace an existing destination on rename.
            fs::remove(destination, ec);
            ec.clear();
            fs::rename(temporary, destination, ec);
        }
        if (ec) {
            std::cerr << "Impossible de finaliser la sauvegarde : " << ec.message() << '\n';
            return false;
        }
        return true;
    } catch (const std::exception& error) {
        std::cerr << "Erreur de sauvegarde mémoire : " << error.what() << '\n';
        return false;
    }
}

void Memory::resetHistory() {
    data_["messages"] = nlohmann::json::array();
    save();
}

void Memory::addExchange(const std::string& user, const std::string& assistant) {
    data_["messages"].push_back({{"role", "user"}, {"content", user}});
    data_["messages"].push_back({{"role", "assistant"}, {"content", assistant}});
    trimHistory();
    save();
}

const nlohmann::json& Memory::profile() const { return data_["profile"]; }
const nlohmann::json& Memory::messages() const { return data_["messages"]; }
nlohmann::json& Memory::profile() { return data_["profile"]; }

} // namespace joyce
