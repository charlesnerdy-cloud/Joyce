#include "joyce/ollama_client.hpp"

#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <sstream>
#include <utility>

namespace joyce {
namespace {
using json = nlohmann::json;

std::size_t receiveData(void* contents, std::size_t size, std::size_t nmemb, void* userData) {
    const std::size_t bytes = size * nmemb;
    auto* output = static_cast<std::string*>(userData);
    output->append(static_cast<const char*>(contents), bytes);
    return bytes;
}
} // namespace

OllamaClient::OllamaClient(Config config) : config_(std::move(config)) {}
const Config& OllamaClient::config() const { return config_; }

std::string OllamaClient::systemPrompt(const Memory& memory) const {
    return "Tu es Joyce, une assistante IA locale. Réponds en français, de façon naturelle, "
           "utile et concise. Utilise le profil persistant comme contexte. Ne prétends jamais "
           "avoir effectué une action que tu n'as pas réalisée. Tu peux aider à développer "
           "le projet et analyser les données qui te sont fournies. Ne prétends pas observer "
           "Apex Legends si aucune source de données autorisée n'est connectée. "
           "Ne propose pas de contourner l'anti-triche, de lire la mémoire du jeu ou d'injecter "
           "des commandes dans le jeu.\n\nProfil :\n" + memory.profile().dump(2);
}

bool OllamaClient::ask(const std::string& userText, const Memory& memory,
                       std::string& answer, std::string& error) const {
    json request;
    request["model"] = config_.model;
    request["stream"] = false;
    request["messages"] = json::array();
    request["messages"].push_back({{"role", "system"}, {"content", systemPrompt(memory)}});
    for (const auto& message : memory.messages()) request["messages"].push_back(message);
    request["messages"].push_back({{"role", "user"}, {"content", userText}});

    const std::string body = request.dump();
    std::string response;
    CURL* curl = curl_easy_init();
    if (!curl) {
        error = "Impossible d'initialiser le client HTTP.";
        return false;
    }

    curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    curl_easy_setopt(curl, CURLOPT_URL, config_.apiUrl.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receiveData);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, config_.connectTimeoutSeconds);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, config_.requestTimeoutSeconds);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    const CURLcode result = curl_easy_perform(curl);
    long status = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (result != CURLE_OK) {
        error = std::string("Connexion à Ollama impossible : ") + curl_easy_strerror(result);
        return false;
    }
    if (status < 200 || status >= 300) {
        error = "Ollama a répondu avec le statut HTTP " + std::to_string(status) + ".";
        try {
            const auto data = json::parse(response);
            if (data.contains("error")) error += " Détail : " + data["error"].get<std::string>();
        } catch (...) {}
        return false;
    }

    try {
        const json data = json::parse(response);
        answer = data.at("message").at("content").get<std::string>();
        if (answer.empty()) {
            error = "Ollama a renvoyé une réponse vide.";
            return false;
        }
        return true;
    } catch (const std::exception& exception) {
        error = std::string("Réponse Ollama illisible : ") + exception.what();
        return false;
    }
}

} // namespace joyce
