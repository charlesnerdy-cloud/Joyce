#include "joyce/app.hpp"

#include <algorithm>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>

namespace joyce {
namespace {
using json = nlohmann::json;
std::string nowText() {
    const std::time_t now = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &now);
#else
    localtime_r(&now, &tm);
#endif
    char buffer[32]{};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &tm);
    return buffer;
}
std::string trimLeft(std::string value) {
    const auto first = value.find_first_not_of(" \t");
    return first == std::string::npos ? std::string{} : value.substr(first);
}
std::string trim(std::string value) {
    const auto first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}
bool nonNegativeNumber(const json& obj, const char* key) {
    return obj.contains(key) && obj[key].is_number() && obj[key].get<double>() >= 0;
}
json normalizeImportedSession(const json& input) {
    json s = json::object();
    if (!input.is_object()) return s;
    const auto copyString = [&](const char* key) {
        if (input.contains(key) && input[key].is_string()) s[key] = input[key];
    };
    const auto copyNumber = [&](const char* key) {
        if (nonNegativeNumber(input, key)) s[key] = input[key];
    };
    copyString("legend"); copyString("started_at"); copyString("ended_at"); copyString("date");
    copyNumber("kills"); copyNumber("damage"); copyNumber("placement");
    if (input.contains("notes") && input["notes"].is_array()) s["notes"] = input["notes"];
    else s["notes"] = json::array();
    if (!s.contains("legend")) s["legend"] = "Inconnue";
    if (!s.contains("started_at")) s["started_at"] = input.value("date", nowText());
    s["ended_at"] = input.value("ended_at", s.value("date", nowText()));
    s["status"] = "importée depuis un fichier fourni par l'utilisateur";
    s["source"] = "import utilisateur";
    return s;
}
}

App::App(Config config)
    : config_(std::move(config)), memory_(config_.memoryFile, config_.maxMessages),
      ollama_(config_), journal_(json::object()),
      journalFile_(envOr("JOYCE_MATCHES_FILE", "data/joyce_matches.json")) {}

bool App::loadJournal() {
    std::ifstream file(journalFile_);
    if (!file) {
        journal_ = {{"sessions", json::array()}, {"current", nullptr}};
        return saveJournal();
    }
    try {
        file >> journal_;
        if (!journal_.is_object()) journal_ = json::object();
        if (!journal_.contains("sessions") || !journal_["sessions"].is_array()) journal_["sessions"] = json::array();
        if (!journal_.contains("current")) journal_["current"] = nullptr;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Journal de parties illisible : " << e.what() << "\n";
        journal_ = {{"sessions", json::array()}, {"current", nullptr}};
        return saveJournal();
    }
}

bool App::saveJournal() const {
    namespace fs = std::filesystem;
    try {
        const fs::path destination(journalFile_);
        if (!destination.parent_path().empty()) fs::create_directories(destination.parent_path());
        const std::string tmp = journalFile_ + ".tmp";
        { std::ofstream out(tmp, std::ios::trunc); if (!out) return false; out << journal_.dump(2) << '\n'; if (!out) return false; }
        std::error_code ec;
        fs::rename(tmp, destination, ec);
        if (ec) { fs::remove(destination, ec); ec.clear(); fs::rename(tmp, destination, ec); }
        return !ec;
    } catch (...) { return false; }
}

void App::printHelp() const {
    std::cout << "Commandes disponibles :\n"
              << "  /help                         Afficher cette aide\n"
              << "  /profil                       Afficher le profil persistant\n"
              << "  /profil-set <champ> <valeur>  Modifier le profil\n"
              << "  /status                       Afficher l'état de Joyce et d'Apex\n"
              << "  /apex                         Vérifier la source d'observation\n"
              << "  /coach <situation>            Coaching tactique contextualisé\n"
              << "  /partie nouvelle <légende>    Démarrer une fiche de partie\n"
              << "  /note <observation>           Ajouter une note à la partie\n"
              << "  /fin [kills] [dégâts] [rang]  Terminer et enregistrer la partie\n"
              << "  /bilan                        Analyser la dernière partie\n"
              << "  /stats                        Résumé des parties enregistrées\n"
              << "  /insights                     Tendances et axes de progression\n"
              << "  /import-json <fichier>        Importer des parties depuis un JSON local\n"
              << "  /export-json <fichier>        Exporter le journal de parties\n"
              << "  /reset                        Effacer l'historique de discussion\n"
              << "  /quit                         Quitter Joyce\n\n"
              << "Les données de partie sont saisies ou importées depuis un fichier que tu fournis. Joyce ne lit pas le jeu en direct.\n\n";
}

void App::printStatus() const {
    const Observation observation = apex_.observe();
    std::cout << "Modèle Ollama : " << config_.model << '\n'
              << "API : " << config_.apiUrl << '\n'
              << "Fichier mémoire : " << config_.memoryFile << '\n'
              << "Fichier de parties : " << journalFile_ << '\n'
              << "Messages conservés : " << memory_.messages().size() << '\n'
              << "Parties enregistrées : " << journal_["sessions"].size() << '\n'
              << "Observation Apex : " << (observation.available ? "disponible" : "non connectée")
              << " (source : " << observation.source << ")\n\n";
}

void App::printStats() const {
    const auto& sessions = journal_["sessions"];
    std::size_t totalKills = 0, killsCount = 0, topFive = 0, wins = 0;
    double totalDamage = 0.0, totalPlacement = 0.0;
    std::size_t damageCount = 0, placementCount = 0;
    for (const auto& s : sessions) {
        if (nonNegativeNumber(s, "kills")) { totalKills += s["kills"].get<std::size_t>(); ++killsCount; }
        if (nonNegativeNumber(s, "damage")) { totalDamage += s["damage"].get<double>(); ++damageCount; }
        if (s.contains("placement") && s["placement"].is_number_integer() && s["placement"].get<int>() >= 1) {
            const int p = s["placement"].get<int>(); totalPlacement += p; ++placementCount;
            if (p <= 5) ++topFive; if (p == 1) ++wins;
        }
    }
    std::cout << "Parties enregistrées : " << sessions.size() << "\nTotal éliminations : " << totalKills << '\n';
    if (damageCount) std::cout << "Dégâts moyens saisis : " << static_cast<long>(totalDamage / damageCount) << '\n';
    if (killsCount) std::cout << "Éliminations moyennes saisies : " << std::fixed << std::setprecision(2) << static_cast<double>(totalKills) / killsCount << '\n';
    if (placementCount) std::cout << "Rang moyen saisi : " << std::fixed << std::setprecision(2) << totalPlacement / placementCount << '\n'
                                  << "Top 5 : " << topFive << " | Victoires : " << wins << '\n';
    if (journal_["current"].is_object()) std::cout << "Partie en cours : oui (" << journal_["current"].value("legend", "légende inconnue") << ")\n";
    else std::cout << "Partie en cours : non\n";
    std::cout << "Ces statistiques reflètent uniquement les parties enregistrées ou importées.\n\n";
}

std::string App::progressionContext(std::size_t limit) const {
    json recent = json::array();
    const auto& sessions = journal_["sessions"];
    const std::size_t start = sessions.size() > limit ? sessions.size() - limit : 0;
    for (std::size_t i = start; i < sessions.size(); ++i) recent.push_back(sessions[i]);
    json summary = {{"nombre_total", sessions.size()}, {"parties_recentes", recent}};
    return summary.dump(2);
}

void App::coach(const std::string& situation) {
    if (situation.empty()) { std::cout << "Usage : /coach <situation, position, équipement, équipe adverse...>\n\n"; return; }
    const std::string prompt =
        "Agis comme coach tactique expert d'Apex Legends. Utilise le profil joueur et les dernières fiches si elles sont pertinentes. "
        "Distingue explicitement les faits fournis des hypothèses. Réponds en 4 rubriques : 1) priorité immédiate, "
        "2) plan de 10 à 20 secondes, 3) risque principal, 4) alternative si le plan échoue. "
        "Adapte le conseil à la légende principale et aux objectifs si renseignés. Sois bref, concret, et ne prétends jamais voir la partie. "
        "Si une information essentielle manque, donne une option prudente plutôt que d'inventer. "
        "Contexte de progression connu (saisie manuelle/import utilisateur) : " + progressionContext(5) +
        "\nSituation fournie : " + situation;
    std::string answer, error;
    std::cout << "Joyce analyse la situation...\n";
    if (!ollama_.ask(prompt, memory_, answer, error)) { std::cerr << "Erreur Ollama : " << error << "\n\n"; return; }
    std::cout << "\nCoach Joyce > " << answer << "\n\n";
    memory_.addExchange(prompt, answer);
}

void App::reviewLastSession() {
    json session;
    if (journal_["current"].is_object()) session = journal_["current"];
    else if (!journal_["sessions"].empty()) session = journal_["sessions"].back();
    else { std::cout << "Aucune partie enregistrée. Utilise /partie nouvelle <légende> ou /import-json <fichier>.\n\n"; return; }
    const std::string prompt = "Agis comme coach de progression Apex Legends. Fais un bilan bienveillant et concret à partir de cette fiche saisie/importée : " + session.dump(2) +
        ". Donne les points forts possibles, les axes à travailler et trois exercices précis. Signale ce qui manque au lieu d'inventer des statistiques. "
        "Ne déduis pas la qualité de l'équipe ou des combats à partir du rang seul. Joyce ne dispose pas de données de jeu automatiques.";
    std::string answer, error;
    std::cout << "Joyce prépare le bilan...\n";
    if (!ollama_.ask(prompt, memory_, answer, error)) { std::cerr << "Erreur Ollama : " << error << "\n\n"; return; }
    std::cout << "\nBilan Joyce > " << answer << "\n\n";
    memory_.addExchange(prompt, answer);
}

void App::printInsights() {
    const auto& sessions = journal_["sessions"];
    if (sessions.empty()) { std::cout << "Pas encore assez de données. Enregistre des parties avec /partie nouvelle puis /fin, ou importe un JSON.\n\n"; return; }
    std::size_t killsCount = 0, damageCount = 0, placementCount = 0, topFive = 0, wins = 0;
    double kills = 0, damage = 0, placement = 0;
    for (const auto& s : sessions) {
        if (nonNegativeNumber(s, "kills")) { kills += s["kills"].get<double>(); ++killsCount; }
        if (nonNegativeNumber(s, "damage")) { damage += s["damage"].get<double>(); ++damageCount; }
        if (s.contains("placement") && s["placement"].is_number_integer() && s["placement"].get<int>() >= 1) {
            const int p = s["placement"].get<int>(); placement += p; ++placementCount; if (p <= 5) ++topFive; if (p == 1) ++wins;
        }
    }
    json metrics = {{"parties", sessions.size()}, {"profil", memory_.profile()}, {"fiches_recentes", json::parse(progressionContext(10))}};
    if (killsCount) metrics["eliminations_moyennes"] = kills / killsCount;
    if (damageCount) metrics["degats_moyens"] = damage / damageCount;
    if (placementCount) { metrics["rang_moyen"] = placement / placementCount; metrics["top5"] = topFive; metrics["victoires"] = wins; }
    std::cout << "Tendances calculées à partir de " << sessions.size() << " partie(s) enregistrée(s).\n"
              << "Éliminations moyennes : " << (killsCount ? std::to_string(kills / killsCount) : "données manquantes") << '\n'
              << "Dégâts moyens : " << (damageCount ? std::to_string(damage / damageCount) : "données manquantes") << '\n'
              << "Rang moyen : " << (placementCount ? std::to_string(placement / placementCount) : "données manquantes") << '\n';
    const std::string prompt = "Tu es coach personnel Apex Legends. Analyse les données ci-dessous avec prudence : elles sont uniquement saisies/importées par le joueur, pas observées automatiquement. Repère tendances possibles, données insuffisantes, 2 priorités mesurables pour les 5 prochaines parties et 3 exercices courts. Ne présente pas une corrélation comme une certitude et n'invente aucune statistique. Données : " + metrics.dump(2);
    std::string answer, error;
    std::cout << "\nJoyce construit un plan personnalisé...\n";
    if (!ollama_.ask(prompt, memory_, answer, error)) { std::cerr << "Erreur Ollama : " << error << "\n\n"; return; }
    std::cout << "\nPlan de progression Joyce > " << answer << "\n\n";
    memory_.addExchange(prompt, answer);
}

void App::importJson(const std::string& path) {
    std::string filePath = trim(path);
    if (filePath.size() >= 2 && ((filePath.front() == '"' && filePath.back() == '"') || (filePath.front() == '\'' && filePath.back() == '\''))) filePath = filePath.substr(1, filePath.size() - 2);
    if (filePath.empty()) { std::cout << "Usage : /import-json <chemin-vers-un-fichier.json>\n\n"; return; }
    try {
        std::ifstream file(filePath);
        if (!file) { std::cout << "Impossible d'ouvrir le fichier : " << filePath << "\n\n"; return; }
        json input; file >> input;
        json entries = json::array();
        if (input.is_array()) entries = input;
        else if (input.is_object() && input.contains("sessions") && input["sessions"].is_array()) entries = input["sessions"];
        else if (input.is_object() && input.contains("matches") && input["matches"].is_array()) entries = input["matches"];
        else if (input.is_object()) entries.push_back(input);
        else { std::cout << "Format JSON non reconnu : attendu un objet, un tableau, ou un champ sessions/matches.\n\n"; return; }
        std::size_t imported = 0;
        for (const auto& entry : entries) {
            json session = normalizeImportedSession(entry);
            if (session.empty()) continue;
            if (!session.contains("kills") && !session.contains("damage") && !session.contains("placement")) continue;
            journal_["sessions"].push_back(std::move(session)); ++imported;
        }
        if (saveJournal()) std::cout << imported << " partie(s) importée(s). Les champs absents restent inconnus.\n\n";
        else std::cout << "Import effectué en mémoire, mais la sauvegarde a échoué.\n\n";
    } catch (const std::exception& e) { std::cout << "Import impossible : " << e.what() << "\nVérifie que le fichier est un JSON valide.\n\n"; }
}

void App::exportJson(const std::string& path) const {
    std::string filePath = trim(path);
    if (filePath.size() >= 2 && ((filePath.front() == '"' && filePath.back() == '"') || (filePath.front() == '\'' && filePath.back() == '\''))) filePath = filePath.substr(1, filePath.size() - 2);
    if (filePath.empty()) { std::cout << "Usage : /export-json <chemin-vers-un-fichier.json>\n\n"; return; }
    try {
        const std::filesystem::path destination(filePath);
        if (!destination.parent_path().empty()) std::filesystem::create_directories(destination.parent_path());
        std::ofstream file(destination, std::ios::trunc);
        if (!file) { std::cout << "Impossible d'écrire dans : " << filePath << "\n\n"; return; }
        file << journal_.dump(2) << '\n';
        std::cout << "Journal exporté vers : " << filePath << "\n\n";
    } catch (const std::exception& e) { std::cout << "Export impossible : " << e.what() << "\n\n"; }
}

void App::handleInput(const std::string& input, bool& keepRunning) {
    if (input == "/quit" || input == "/exit") { keepRunning = false; return; }
    if (input == "/help") { printHelp(); return; }
    if (input == "/profil") { std::cout << memory_.profile().dump(2) << "\n\n"; return; }
    if (input.rfind("/profil-set ", 0) == 0) {
        std::istringstream stream(input.substr(12)); std::string key; stream >> key;
        std::string value; std::getline(stream, value); value = trimLeft(value);
        if (key.empty() || value.empty()) { std::cout << "Usage : /profil-set <champ> <valeur>\nExemple : /profil-set main_legend Wraith\n\n"; return; }
        if (key == "name" || key == "language" || key == "style" || key == "project" || key == "main_legend" || key == "goals" || key == "playstyle") {
            memory_.profile()[key] = value;
            if (memory_.save()) std::cout << "Profil mis à jour : " << key << " = " << value << "\n\n";
            else std::cout << "Profil modifié en mémoire, mais sauvegarde échouée.\n\n";
        } else std::cout << "Champ non autorisé. Champs : name, language, style, project, main_legend, goals, playstyle.\n\n";
        return;
    }
    if (input == "/status") { printStatus(); return; }
    if (input == "/apex") { const Observation o = apex_.observe(); std::cout << "Apex : " << o.summary << "\nJoyce n'analyse pas le jeu en direct ; utilise /coach avec une description ou importe des statistiques disponibles.\n\n"; return; }
    if (input == "/reset") { memory_.resetHistory(); std::cout << "Historique effacé. Profil conservé. Les fiches de partie ne sont pas supprimées.\n\n"; return; }
    if (input == "/stats") { printStats(); return; }
    if (input == "/insights") { printInsights(); return; }
    if (input == "/bilan") { reviewLastSession(); return; }
    if (input.rfind("/coach", 0) == 0 && (input.size() == 6 || input[6] == ' ')) { coach(trimLeft(input.substr(6))); return; }
    if (input.rfind("/import-json", 0) == 0 && (input.size() == 12 || input[12] == ' ')) { importJson(trim(input.substr(12))); return; }
    if (input.rfind("/export-json", 0) == 0 && (input.size() == 12 || input[12] == ' ')) { exportJson(trim(input.substr(12))); return; }
    if (input.rfind("/partie nouvelle", 0) == 0) {
        const std::string legend = trimLeft(input.substr(std::string("/partie nouvelle").size()));
        if (legend.empty()) { std::cout << "Usage : /partie nouvelle <légende>\n\n"; return; }
        if (journal_["current"].is_object()) { std::cout << "Une partie est déjà en cours. Termine-la avec /fin ou note-la avant d'en démarrer une autre.\n\n"; return; }
        journal_["current"] = {{"started_at", nowText()}, {"legend", legend}, {"notes", json::array()}, {"status", "enregistrée manuellement"}, {"source", "saisie utilisateur"}};
        std::cout << (saveJournal() ? "Fiche de partie démarrée pour " + legend + ". Utilise /note pour ajouter du contexte.\n\n" : "Erreur de sauvegarde du journal.\n\n"); return;
    }
    if (input.rfind("/note", 0) == 0 && (input.size() == 5 || input[5] == ' ')) {
        const std::string note = trimLeft(input.substr(5));
        if (note.empty()) { std::cout << "Usage : /note <observation>\n\n"; return; }
        if (!journal_["current"].is_object()) { std::cout << "Pas de partie en cours. Démarre-en une avec /partie nouvelle <légende>.\n\n"; return; }
        journal_["current"]["notes"].push_back({{"at", nowText()}, {"text", note}});
        std::cout << (saveJournal() ? "Note enregistrée.\n\n" : "Erreur de sauvegarde de la note.\n\n"); return;
    }
    if (input.rfind("/fin", 0) == 0 && (input.size() == 4 || input[4] == ' ')) {
        if (!journal_["current"].is_object()) { std::cout << "Aucune partie en cours.\n\n"; return; }
        std::istringstream args(input.substr(4)); int kills = -1, damage = -1, rank = -1; args >> kills >> damage >> rank;
        if (kills >= 0) journal_["current"]["kills"] = kills;
        if (damage >= 0) journal_["current"]["damage"] = damage;
        if (rank >= 1 && rank <= 20) journal_["current"]["placement"] = rank;
        journal_["current"]["ended_at"] = nowText(); journal_["current"]["status"] = "terminée";
        journal_["sessions"].push_back(journal_["current"]); journal_["current"] = nullptr;
        std::cout << (saveJournal() ? "Partie enregistrée. Utilise /bilan ou /insights pour obtenir une analyse.\n\n" : "Erreur de sauvegarde du journal.\n\n"); return;
    }
    if (!input.empty() && input.front() == '/') { std::cout << "Commande inconnue. Tape /help pour la liste.\n\n"; return; }
    std::string answer, error; std::cout << "Joyce réfléchit...\n";
    if (!ollama_.ask(input, memory_, answer, error)) {
        std::cerr << "Joyce n'a pas pu répondre : " << error << '\n' << "Vérifie qu'Ollama est démarré et que le modèle '" << config_.model << "' est installé. L'historique n'a pas été modifié.\n\n"; return;
    }
    std::cout << "\nJoyce > " << answer << "\n\n"; memory_.addExchange(input, answer);
}

int App::run() {
    if (!memory_.load()) std::cerr << "Attention : la mémoire n'a pas pu être sauvegardée.\n";
    if (!loadJournal()) std::cerr << "Attention : le journal des parties n'a pas pu être sauvegardé.\n";
    std::cout << "========================================\n" << " Joyce V3 - Assistant IA local et coach Apex\n"
              << " Modèle : " << config_.model << "\n" << " Mémoire : " << config_.memoryFile << "\n"
              << " Tape /help pour les commandes.\n" << "========================================\n\n";
    bool keepRunning = true; std::string input;
    while (keepRunning) { std::cout << "Toi > " << std::flush; if (!std::getline(std::cin, input)) break; if (input.empty()) continue; handleInput(input, keepRunning); }
    std::cout << "Joyce est arrêtée. La mémoire est conservée.\n"; return 0;
}

} // namespace joyce
