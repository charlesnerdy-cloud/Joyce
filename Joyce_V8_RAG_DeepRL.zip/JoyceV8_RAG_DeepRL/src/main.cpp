#include "joyce/app.hpp"

#include <curl/curl.h>
#include <exception>
#include <iostream>

int main() {
    const CURLcode initResult = curl_global_init(CURL_GLOBAL_DEFAULT);
    if (initResult != CURLE_OK) {
        std::cerr << "Impossible d'initialiser libcurl.\n";
        return 1;
    }

    int exitCode = 0;
    try {
        joyce::App app(joyce::Config{});
        exitCode = app.run();
    } catch (const std::exception& error) {
        std::cerr << "Erreur fatale : " << error.what() << '\n';
        exitCode = 1;
    }

    curl_global_cleanup();
    return exitCode;
}
