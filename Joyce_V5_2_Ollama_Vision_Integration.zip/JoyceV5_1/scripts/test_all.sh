#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JOBS="${JOYCE_BUILD_JOBS:-2}"
echo "=========================================="
echo " Joyce — compilation et tests complets"
echo "=========================================="
command -v cmake >/dev/null || { echo "ERREUR : cmake est absent."; exit 2; }
command -v c++ >/dev/null || { echo "ERREUR : compilateur C++ absent."; exit 2; }
command -v python3 >/dev/null || { echo "ERREUR : python3 est absent."; exit 2; }
# Répare automatiquement un cache CMake copié depuis un autre emplacement.
if [[ -f "$ROOT/build/CMakeCache.txt" ]] && ! grep -Fq "CMAKE_HOME_DIRECTORY:INTERNAL=$ROOT" "$ROOT/build/CMakeCache.txt"; then
  echo "Cache CMake d'un autre chemin détecté : reconstruction propre du dossier build."
  rm -rf "$ROOT/build"
fi
cmake -S "$ROOT" -B "$ROOT/build" -DCMAKE_BUILD_TYPE=Release
cmake --build "$ROOT/build" --parallel "$JOBS"
python3 "$ROOT/tests/test_all.py" "$ROOT/build/joyce"
python3 "$ROOT/tests/test_dashboard.py"
python3 "$ROOT/tests/test_vision_wrapper.py"
python3 "$ROOT/tests/test_vision_coach.py"
ctest --test-dir "$ROOT/build" --output-on-failure
