# Joyce — assistant IA local

Joyce est un assistant en ligne de commande en C++17 qui dialogue avec un modèle Ollama local et conserve un profil ainsi qu'un historique sur disque. Le module Apex est une interface passive d'extension : **il n'observe pas encore le jeu**.

## Prérequis (Debian/Ubuntu)

```bash
sudo apt update
sudo apt install -y build-essential cmake pkg-config libcurl4-openssl-dev nlohmann-json3-dev
```

Installer Ollama depuis sa source officielle, puis démarrer le service. Télécharger le modèle utilisé par défaut :

```bash
ollama pull qwen2.5:3b
ollama list
```

Vérifier qu'Ollama répond avant de lancer Joyce :

```bash
curl http://localhost:11434/api/tags
```

## Compilation et lancement

Depuis le dossier du projet :

```bash
./scripts/build.sh
./scripts/run.sh
```

Ou manuellement :

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
./build/joyce
```

## Commandes Joyce

- `/help` : afficher les commandes.
- `/profil` : afficher le profil persistant.
- `/status` : afficher la configuration et l'état du module Apex.
- `/apex` : vérifier l'état de l'adaptateur Apex.
- `/coach <situation>` : obtenir un conseil tactique à partir de la situation décrite.
- `/profil-set <champ> <valeur>` : modifier `main_legend`, `goals`, `playstyle`, `name`, `language`, `style` ou `project`.
- `/partie nouvelle <légende>` : ouvrir une fiche de partie.
- `/note <observation>` : enregistrer un événement ou une décision dans la fiche en cours.
- `/fin [kills] [dégâts] [rang]` : terminer la fiche et enregistrer les statistiques facultatives.
- `/bilan` : demander à Ollama une analyse de la dernière fiche.
- `/stats` : afficher un résumé des fiches enregistrées.
- `/reset` : effacer uniquement l'historique des conversations.
- `/quit` ou `/exit` : quitter.

Le profil et l’historique sont stockés dans `data/joyce_memory.json`. Les fiches de parties sont stockées dans `data/joyce_matches.json`. L'historique garde au maximum 20 messages (les échanges les plus anciens sont supprimés en premier). La sauvegarde passe par un fichier temporaire avant remplacement.

## Configuration par variables d'environnement

Les valeurs par défaut conviennent à une installation locale :

```bash
export JOYCE_MODEL='qwen2.5:3b'
export JOYCE_API_URL='http://localhost:11434/api/chat'
export JOYCE_MEMORY_FILE='data/joyce_memory.json'
./scripts/run.sh
```

`JOYCE_MEMORY_FILE` peut être un chemin absolu si tu veux garder la mémoire à un autre emplacement.

## Architecture

- `src/main.cpp` : initialisation et arrêt de libcurl.
- `src/app.cpp` : boucle de conversation et commandes.
- `src/ollama_client.cpp` : requêtes HTTP vers l'API Ollama.
- `src/memory.cpp` : chargement, validation et sauvegarde du profil/historique.
- `src/apex_adapter.cpp` : point d'extension passif pour des observations autorisées.

## Limites actuelles et sécurité

Joyce ne lit pas la mémoire d'Apex Legends, n'injecte aucune entrée dans le jeu et ne contourne aucun anti-triche. Le module Apex retourne volontairement « aucune source connectée » tant qu'une source documentée et autorisée n'est pas intégrée. Les fonctionnalités d’analyse en direct ne sont donc pas présentes dans cette version. Les conseils tactiques et bilans s’appuient uniquement sur les descriptions et statistiques saisies par l’utilisateur ; Joyce ne doit pas inventer les données manquantes.

La conversation est envoyée au serveur Ollama configuré. Avec l'URL par défaut, les requêtes restent sur la machine locale ; ne configure pas une URL distante si tu ne souhaites pas lui transmettre tes messages.
