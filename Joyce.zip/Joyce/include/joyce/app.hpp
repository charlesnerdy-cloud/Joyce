#pragma once

#include "joyce/apex_adapter.hpp"
#include "joyce/config.hpp"
#include "joyce/memory.hpp"
#include "joyce/ollama_client.hpp"

namespace joyce {

class App {
public:
    explicit App(Config config);
    int run();

private:
    Config config_;
    Memory memory_;
    OllamaClient ollama_;
    ApexAdapter apex_;

    void printHelp() const;
    void printStatus() const;
    void handleInput(const std::string& input, bool& keepRunning);
};

} // namespace joyce
