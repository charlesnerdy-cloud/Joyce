#include "joyce/app.hpp"

#include <iostream>
#include <string>
#include <utility>

namespace joyce {

App::App(Config config)
    : config_(std::move(config)), memory_(config_.memoryFile, config_.maxMessages),
      ollama_(config_) {}

void App::printHelp() const {
    std::cout << "Commandes disponibles :\n"
              << "  /help    Afficher cette aide\n"
              << "  /profil  Afficher le profil persistant\n"
              << "  /status  Afficher la configuration et l'état du module Apex\n"
              << "  /apex    Vérifier si une observation Apex est disponible\n"
              << "  /reset   Effacer l'historique, sans effacer le profil\n"
              << "  /quit    Quitter Joyce\n\n";
}

void App::printStatus() const {
    const Observation observation = apex_.observe();
    std::cout << "Modèle Ollama : " << config_.model << '\n'
              << "API : " << config_.apiUrl << '\n'
              << "Fichier mémoire : " << config_.memoryFile << '\n'
              << "Messages conservés : " << memory_.messages().size() << '\n'
              << "Observation Apex : " << (observation.available ? "disponible" : "non connectée")
              << " (source : " << observation.source << ")\n\n";
}

void App::handleInput(const std::string& input, bool& keepRunning) {
    if (input == "/quit" || input == "/exit") {
        keepRunning = false;
        return;
    }
    if (input == "/help") { printHelp(); return; }
    if (input == "/profil") {
        std::cout << memory_.profile().dump(2) << "\n\n";
        return;
    }
    if (input == "/status") { printStatus(); return; }
    if (input == "/apex") {
        const Observation observation = apex_.observe();
        std::cout << "Apex : " << observation.summary << "\n"
                  << "Joyce n'analyse pas le jeu en direct à ce stade.\n\n";
        return;
    }
    if (input == "/reset") {
        memory_.resetHistory();
        std::cout << "Historique effacé. Profil conservé.\n\n";
        return;
    }
    if (!input.empty() && input.front() == '/') {
        std::cout << "Commande inconnue. Tape /help pour la liste.\n\n";
        return;
    }

    std::string answer;
    std::string error;
    std::cout << "Joyce réfléchit...\n";
    if (!ollama_.ask(input, memory_, answer, error)) {
        std::cerr << "Joyce n'a pas pu répondre : " << error << '\n'
                  << "Vérifie qu'Ollama est démarré et que le modèle '"
                  << config_.model << "' est installé. L'historique n'a pas été modifié.\n\n";
        return;
    }

    std::cout << "\nJoyce > " << answer << "\n\n";
    memory_.addExchange(input, answer);
}

int App::run() {
    if (!memory_.load()) {
        std::cerr << "Attention : la mémoire n'a pas pu être sauvegardée.\n";
    }

    std::cout << "========================================\n"
              << " Joyce - Assistant IA local\n"
              << " Modèle : " << config_.model << "\n"
              << " Mémoire : " << config_.memoryFile << "\n"
              << " Tape /help pour les commandes.\n"
              << "========================================\n\n";

    bool keepRunning = true;
    std::string input;
    while (keepRunning) {
        std::cout << "Toi > " << std::flush;
        if (!std::getline(std::cin, input)) break;
        if (input.empty()) continue;
        handleInput(input, keepRunning);
    }

    std::cout << "Joyce est arrêtée. La mémoire est conservée.\n";
    return 0;
}

} // namespace joyce
